package GUI;

/** CAHS Department panel - shows only the attendance of students whose department is CAHS. */
public class CAHSPanel extends AttendanceTablePanel {
    public CAHSPanel() {
        super("CAHS", "CAHS DEPARTMENT", "College of Allied Health Sciences \u2022 BS Nursing, Medical Technology, Pharmacy, Psychology");
    }
}
