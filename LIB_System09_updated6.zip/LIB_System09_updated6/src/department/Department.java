package department;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Course -> department mapping, read from YOUR database (course_tbl joined with dept_tbl),
 * so adding a course or moving it to another department in phpMyAdmin is picked up automatically.
 *
 * A course is identified in the program by its COURSE CODE (BSIT, BSN, ...).
 * To show the full course name instead, change COURSE_COLUMN to "course_name".
 */
public final class Department {

    /** The departments that have a button in the sidebar (six college departments + Senior High School). */
    public static final String[] DEPARTMENTS = {"CAHS", "CEA", "CITE", "CMA", "COE", "SCCJ", "SHS"};

    /** dept_tbl.department_code used for Senior High School (its strands are stored in course_tbl). */
    public static final String SHS = "SHS";

    /** course_tbl column used as the course text everywhere ("course_code" or "course_name"). */
    public static final String COURSE_COLUMN = "course_code";

    private static final Map<String, String> COURSE_TO_DEPT = new LinkedHashMap<>();
    private static final Map<String, String> COURSE_NAMES = new LinkedHashMap<>();
    private static boolean loaded;
    private static long lastFailure;

    private Department() { }

    /** Reads course_tbl / dept_tbl again (call after changing them while the program is running). */
    public static synchronized void reload() {
        String sql = "SELECT c." + COURSE_COLUMN + ", c.course_name, d.department_code "
                   + "FROM course_tbl c JOIN dept_tbl d ON d.department_id = c.department_id "
                   + "ORDER BY c.department_id, c.course_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            COURSE_TO_DEPT.clear();
            COURSE_NAMES.clear();
            while (rs.next()) {
                COURSE_TO_DEPT.put(rs.getString(1), rs.getString(3));
                COURSE_NAMES.put(rs.getString(1), rs.getString(2));
            }
            loaded = true;
        } catch (SQLException ex) {
            lastFailure = System.currentTimeMillis();     // database not reachable; retry in a few seconds
        }
    }

    private static synchronized void ensureLoaded() {
        if (!loaded && System.currentTimeMillis() - lastFailure > 5000) {
            reload();
        }
    }

    /** @return department code (e.g. "CAHS") or "" when the course is unknown. */
    public static synchronized String getDepartment(String course) {
        ensureLoaded();
        if (course == null) {
            return "";
        }
        String c = course.trim();
        String dept = COURSE_TO_DEPT.get(c);
        if (dept != null) {
            return dept;
        }
        for (Map.Entry<String, String> e : COURSE_TO_DEPT.entrySet()) {     // case-insensitive, or by full name
            if (e.getKey().equalsIgnoreCase(c) || COURSE_NAMES.get(e.getKey()).equalsIgnoreCase(c)) {
                return e.getValue();
            }
        }
        return "";
    }

    /** Full course name for a course code, or the text itself when unknown. */
    public static synchronized String getCourseName(String course) {
        ensureLoaded();
        String n = COURSE_NAMES.get(course);
        return n == null ? course : n;
    }

    /** All courses, in the order shown in combo boxes. */
    public static synchronized List<String> getCourses() {
        ensureLoaded();
        return Collections.unmodifiableList(new ArrayList<>(COURSE_TO_DEPT.keySet()));
    }

    /** Courses that belong to one department. */
    public static synchronized List<String> getCourses(String dept) {
        ensureLoaded();
        List<String> list = new ArrayList<>();
        for (Map.Entry<String, String> e : COURSE_TO_DEPT.entrySet()) {
            if (e.getValue().equals(dept)) {
                list.add(e.getKey());
            }
        }
        return list;
    }
}
