package GUI;

import department.Department;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import model.Staff;

/**
 * Shared window for Admin_Dashboard and Librarian:
 *   top header  - logo, system name, logged-in user
 *   left sidebar - Attendance, Student Records, six department buttons, Log out
 *   centre      - the selected panel
 * Both dashboards only differ in the role and in what StudentManagementPanel allows (fullAccess).
 */
public abstract class DashboardFrame extends JFrame {

    private static final String LOGO = "/GUI/logo-phinma-cagayan-de-oro-removebg.png.png";

    private final boolean fullAccess;
    private final Staff staff;                       // the logged-in account (null when opened directly)
    private final JPanel content = new JPanel();
    private final List<UI.FlatButton> navButtons = new ArrayList<>();
    protected DashboardFrame(String roleTitle, boolean fullAccess) {
        this(roleTitle, fullAccess, null);
    }

    protected DashboardFrame(String roleTitle, boolean fullAccess, Staff staff) {
        super("Library Logbook - " + roleTitle);
        this.fullAccess = fullAccess;
        this.staff = staff;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 660));
        setSize(1200, 720);
        setLocationRelativeTo(null);
        Image logo = UI.image(LOGO);
        if (logo != null) {
            setIconImage(logo);
        }

        // soft page background with rounded blocks (header, sidebar, content) floating on it
        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(UI.PAGE_BG);
        JPanel middle = new JPanel(new BorderLayout(12, 0));
        middle.setOpaque(false);
        content.setLayout(new BorderLayout());
        content.setBackground(UI.PAGE_BG);
        middle.add(buildSidebar(), BorderLayout.WEST);
        middle.add(content, BorderLayout.CENTER);
        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(middle, BorderLayout.CENTER);
        setContentPane(root);

        showPanel(navButtons.get(0), newAttendancePanel());
    }

    private AttendanceTablePanel newAttendancePanel() {
        return new AttendanceTablePanel(null, "LIBRARY LOGGER",
            "All student attendance \u2022 updates automatically when students log in or out");
    }

    // ------------------------------------------------------------------ header

    private JPanel buildHeader() {
        JPanel header = new UI.RoundedPanel(new BorderLayout(), UI.CARD_RADIUS, Color.WHITE, UI.BORDER);
        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        headerRow.setBorder(BorderFactory.createEmptyBorder(6, 18, 6, 22));
        JPanel goldLine = new JPanel();                     // gold accent along the bottom (clipped to the rounded corners)
        goldLine.setBackground(UI.GOLD);
        goldLine.setPreferredSize(new Dimension(0, 3));
        header.add(headerRow, BorderLayout.CENTER);
        header.add(goldLine, BorderLayout.SOUTH);

        // left: logo + system name
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        JLabel logo = new JLabel(UI.scaledIcon(LOGO, 48));
        JLabel name = new JLabel("Library Logger");
        name.setFont(new Font("Serif", Font.BOLD, 22));
        name.setForeground(UI.GREEN);
        JLabel school = new JLabel("PHINMA Cagayan de Oro College");
        school.setFont(new Font("SansSerif", Font.PLAIN, 12));
        school.setForeground(UI.GRAY);
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(name);
        titles.add(school);
        left.add(logo);
        left.add(titles);
        headerRow.add(left, BorderLayout.WEST);

        // right: logged-in user
        String display = staff != null ? staff.getFullName() : (fullAccess ? "Administrator" : "Librarian");
        String username = staff != null ? staff.getUsername() : (fullAccess ? "admin" : "librarian");
        JPanel user = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        user.setOpaque(false);
        JLabel avatar = new JLabel(display.substring(0, 1), SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UI.GREEN);
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        avatar.setPreferredSize(new Dimension(38, 38));
        avatar.setFont(new Font("SansSerif", Font.BOLD, 16));
        avatar.setForeground(Color.WHITE);
        JLabel who = new JLabel(display);
        who.setFont(new Font("SansSerif", Font.BOLD, 14));
        who.setForeground(UI.DARK_GREEN);
        JLabel acct = new JLabel("Logged in as " + username
            + (fullAccess ? " \u2022 full access" : " \u2022 view & update"));
        acct.setFont(new Font("SansSerif", Font.PLAIN, 12));
        acct.setForeground(UI.GRAY);
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.add(who);
        info.add(acct);
        user.add(info);
        user.add(avatar);
        headerRow.add(user, BorderLayout.EAST);
        return header;
    }

    // ------------------------------------------------------------------ sidebar

    private JPanel buildSidebar() {
        JPanel side = new UI.RoundedPanel(null, UI.CARD_RADIUS, UI.GREEN, null);
        side.setPreferredSize(new Dimension(230, 0));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(BorderFactory.createEmptyBorder(22, 16, 18, 16));

        side.add(centered("MENU", new Font("SansSerif", Font.BOLD, 12), UI.GOLD));
        side.add(Box.createVerticalStrut(10));
        side.add(nav("Logbook", UI.Glyph.CLOCK, this::newAttendancePanel));
        side.add(Box.createVerticalStrut(8));
        side.add(nav("Student Records", UI.Glyph.PEOPLE, () -> new StudentManagementPanel(fullAccess)));
        side.add(Box.createVerticalStrut(26));

        side.add(centered("DEPARTMENTS", new Font("SansSerif", Font.BOLD, 12), UI.GOLD));
        side.add(Box.createVerticalStrut(10));
        side.add(deptGrid());
        side.add(Box.createVerticalStrut(8));
        side.add(nav("SENIOR HIGH SCHOOL", null, () -> createDepartmentPanel(Department.SHS)));

        side.add(Box.createVerticalGlue());
        UI.FlatButton logout = UI.button("Log out", UI.DARK_GREEN);
        logout.setIcon(new UI.NavIcon(UI.Glyph.LOGOUT));
        logout.setIconTextGap(10);
        logout.setAlignmentX(Component.CENTER_ALIGNMENT);
        logout.setPreferredSize(new Dimension(100, 40));
        logout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        logout.addActionListener(e -> logout());
        side.add(logout);
        return side;
    }

    private JLabel centered(String text, Font font, Color color) {
        JLabel l = new JLabel(text, SwingConstants.LEFT);
        l.setFont(font);
        l.setForeground(color);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, l.getPreferredSize().height));
        return l;
    }

    private JPanel deptGrid() {
        JPanel grid = new JPanel(new GridLayout(0, 2, 8, 8));
        grid.setOpaque(false);
        for (String d : Department.DEPARTMENTS) {
            if (d.equals(Department.SHS)) {
                continue;                                  // SHS gets its own full-width button below the college grid
            }
            grid.add(nav(d, null, () -> createDepartmentPanel(d)));
        }
        grid.setAlignmentX(Component.CENTER_ALIGNMENT);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 3 * 40 + 16));
        return grid;
    }

    private UI.FlatButton nav(String text, UI.Glyph glyph, java.util.function.Supplier<JPanel> factory) {
        UI.FlatButton b = UI.button(text, UI.DARK_GREEN);
        if (glyph != null) {
            b.setIcon(new UI.NavIcon(glyph));
            b.setIconTextGap(12);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 10));
        }
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        b.setPreferredSize(new Dimension(100, 40));
        b.addActionListener(e -> showPanel(b, factory.get()));
        navButtons.add(b);
        return b;
    }

    private JPanel createDepartmentPanel(String dept) {
        AttendanceTablePanel attendance;
        switch (dept) {
            case "CAHS": attendance = new CAHSPanel(); break;
            case "CEA":  attendance = new CEAPanel();  break;
            case "CITE": attendance = new CITEPanel(); break;
            case "CMA":  attendance = new CMAPanel();  break;
            case "COE":  attendance = new COEPanel();  break;
            case "SHS":  attendance = new SHSPanel();  break;
            default:     attendance = new SCCJPanel(); break;
        }
        return new DepartmentView(fullAccess, dept, attendance);
    }

    private void showPanel(UI.FlatButton source, JPanel panel) {
        for (UI.FlatButton b : navButtons) {
            b.setActive(b == source);
        }
        content.removeAll();
        content.add(panel, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    private void logout() {
        int ok = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?",
                "Confirm Logout", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            new maindashboard().setVisible(true);
            dispose();
        }
    }
}
