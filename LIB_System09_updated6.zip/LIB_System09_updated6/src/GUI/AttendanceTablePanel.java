package GUI;

import database.LoggerDAO;
import department.Department;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 * Attendance table with search / sort / filter. Used by:
 *   - Admin "All Attendance"          (fixedDepartment == null)
 *   - every department panel (CAHS, CITE, ...)   (fixedDepartment == "CAHS", ...)
 * It re-queries the database every few seconds, so a student's Time In / Time Out on the
 * Main Dashboard shows up here automatically without clicking anything.
 */
public class AttendanceTablePanel extends JPanel {

    private static final String[] COLUMNS_ALL  = {"Student ID Number", "Last Name", "First Name", "M.I.",
                                                  "Course", "Department", "Date", "Time In", "Time Out"};
    private static final int REFRESH_MS = 5000;

    private final String fixedDepartment;
    private final DefaultTableModel model;
    private final JTable table;

    private final JTextField txtSearch = UI.textField(13);
    private final JComboBox<String> cbSort = UI.combo(LoggerDAO.SORT_OPTIONS);
    private final JComboBox<String> cbCourse = new JComboBox<>();
    private final JComboBox<String> cbDept;
    private final JCheckBox chkDate = new JCheckBox("Date:");
    private final JSpinner spDate;
    private final JLabel lblCount = new JLabel(" ");
    private final JLabel lblUpdated = new JLabel(" ");

    private final Timer autoRefresh;
    private final Timer debounce;
    private boolean loading;
    private boolean suppressEvents;

    public AttendanceTablePanel(String fixedDepartment, String title, String subtitle) {
        this.fixedDepartment = fixedDepartment;
        setLayout(new BorderLayout(0, 12));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));

        // ---- title
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UI.TITLE);
        lblTitle.setForeground(UI.GREEN);
        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(UI.BODY);
        lblSub.setForeground(UI.GRAY);
        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.add(lblTitle);
        head.add(Box.createVerticalStrut(2));
        head.add(lblSub);

        // ---- filters
        cbDept = new JComboBox<>();
        cbDept.setFont(UI.BODY);
        cbDept.addItem("All Departments");
        for (String d : Department.DEPARTMENTS) {
            cbDept.addItem(d);
        }
        cbDept.setPreferredSize(new Dimension(cbDept.getPreferredSize().width, 34));
        fillCourseCombo(fixedDepartment);
        cbCourse.setFont(UI.BODY);
        cbCourse.setPreferredSize(new Dimension(230, 34));

        spDate = new JSpinner(new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH));
        spDate.setEditor(new JSpinner.DateEditor(spDate, "yyyy-MM-dd"));
        spDate.setFont(UI.BODY);
        spDate.setPreferredSize(new Dimension(130, 34));
        spDate.setEnabled(false);
        chkDate.setOpaque(false);
        chkDate.setFont(UI.LABEL);
        chkDate.setForeground(UI.GREEN);

        JButton btnToday = UI.button("Today", UI.LIGHT_GREEN);
        JButton btnReset = UI.button("Reset", UI.GRAY);
        JButton btnRefresh = UI.button("Refresh", UI.GREEN);

        // two left-aligned rows; FlowLayout never squeezes a component below its normal size
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        row1.setOpaque(false);
        row1.add(UI.label("Search:"));
        row1.add(txtSearch);
        row1.add(Box.createHorizontalStrut(6));
        row1.add(UI.label("Sort by:"));
        row1.add(cbSort);
        row1.add(Box.createHorizontalStrut(6));
        row1.add(chkDate);
        row1.add(spDate);
        row1.add(btnToday);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        row2.setOpaque(false);
        row2.add(UI.label("Course:"));
        row2.add(cbCourse);
        if (fixedDepartment == null) {
            row2.add(Box.createHorizontalStrut(6));
            row2.add(UI.label("Department:"));
            row2.add(cbDept);
        }
        row2.add(Box.createHorizontalStrut(6));
        row2.add(btnReset);
        row2.add(btnRefresh);

        JPanel filters = new UI.RoundedPanel(null, UI.CARD_RADIUS - 4, Color.WHITE, UI.BORDER);   // rounded search panel
        filters.setLayout(new BoxLayout(filters, BoxLayout.Y_AXIS));
        filters.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        filters.add(row1);
        filters.add(row2);

        JPanel north = new JPanel(new BorderLayout(0, 10));
        north.setOpaque(false);
        north.add(head, BorderLayout.NORTH);
        north.add(filters, BorderLayout.CENTER);
        add(north, BorderLayout.NORTH);

        // ---- table
        model = new DefaultTableModel(COLUMNS_ALL, 0) {
            @Override public boolean isCellEditable(int r, int col) { return false; }
        };
        table = new JTable(model);
        UI.styleTable(table);
        if (fixedDepartment != null) {                        
            table.removeColumn(table.getColumnModel().getColumn(5));
        }
        setColumnWidths();
        add(UI.scroll(table), BorderLayout.CENTER);

        // ---- footer
        lblCount.setFont(UI.LABEL);
        lblCount.setForeground(UI.GREEN);
        lblUpdated.setFont(UI.BODY);
        lblUpdated.setForeground(UI.GRAY);
        JPanel foot = new JPanel(new BorderLayout());
        foot.setOpaque(false);
        foot.add(lblCount, BorderLayout.WEST);
        foot.add(lblUpdated, BorderLayout.EAST);
        add(foot, BorderLayout.SOUTH);

        // ---- events
        debounce = new Timer(250, e -> reload());
        debounce.setRepeats(false);
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { debounce.restart(); }
            public void removeUpdate(DocumentEvent e) { debounce.restart(); }
            public void changedUpdate(DocumentEvent e) { debounce.restart(); }
        });
        cbSort.addActionListener(e -> reloadUnlessSuppressed());
        cbCourse.addActionListener(e -> reloadUnlessSuppressed());
        cbDept.addActionListener(e -> {
            if (suppressEvents) {
                return;
            }
            String d = cbDept.getSelectedIndex() <= 0 ? null : (String) cbDept.getSelectedItem();
            fillCourseCombo(d);
            reload();
        });
        chkDate.addActionListener(e -> {
            spDate.setEnabled(chkDate.isSelected());
            reload();
        });
        spDate.addChangeListener(e -> reloadUnlessSuppressed());
        btnToday.addActionListener(e -> {
            suppressEvents = true;
            spDate.setValue(new Date());
            chkDate.setSelected(true);
            spDate.setEnabled(true);
            suppressEvents = false;
            reload();
        });
        btnReset.addActionListener(e -> resetFilters());
        btnRefresh.addActionListener(e -> reload());

        autoRefresh = new Timer(REFRESH_MS, e -> reload());
        reload();
    }

    @Override public void addNotify() { super.addNotify(); autoRefresh.start(); reload(); }
    @Override public void removeNotify() { autoRefresh.stop(); debounce.stop(); super.removeNotify(); }

    /** Preferred widths so nothing is cut off with "..." (window is 1200 px wide by default). */
    private void setColumnWidths() {
        int[] widths = {125, 100, 100, 35, 180, 60, 110, 85, 85};   // same order as COLUMNS_ALL
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            int modelIndex = table.getColumnModel().getColumn(i).getModelIndex();
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[modelIndex]);
        }
        table.getColumnModel().getColumn(table.getColumnModel().getColumnCount() - 1).setMinWidth(70);
    }

    private void fillCourseCombo(String dept) {
        suppressEvents = true;
        cbCourse.removeAllItems();
        cbCourse.addItem("All Courses");
        List<String> courses = dept == null ? Department.getCourses() : Department.getCourses(dept);
        for (String course : courses) {
            cbCourse.addItem(course);
        }
        suppressEvents = false;
    }

    private void reloadUnlessSuppressed() {
        if (!suppressEvents) {
            reload();
        }
    }

    private void resetFilters() {
        suppressEvents = true;
        txtSearch.setText("");
        cbSort.setSelectedIndex(0);
        chkDate.setSelected(false);
        spDate.setEnabled(false);
        spDate.setValue(new Date());
        cbDept.setSelectedIndex(0);
        fillCourseCombo(fixedDepartment);
        suppressEvents = false;
        reload();
    }

    private LoggerDAO.Filter currentFilter() {
        LoggerDAO.Filter f = new LoggerDAO.Filter();
        f.keyword = txtSearch.getText();
        f.sortIndex = cbSort.getSelectedIndex();
        if (chkDate.isSelected()) {
            f.date = ((Date) spDate.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        }
        if (cbCourse.getSelectedIndex() > 0) {
            f.course = (String) cbCourse.getSelectedItem();
        }
        if (fixedDepartment != null) {
            f.department = fixedDepartment;
        } else if (cbDept.getSelectedIndex() > 0) {
            f.department = (String) cbDept.getSelectedItem();
        }
        return f;
    }

    /** Runs the query on a background thread so the window never freezes. */
    public void reload() {
        if (loading) {
            return;
        }
        loading = true;
        final LoggerDAO.Filter f = currentFilter();
        new SwingWorker<List<Object[]>, Void>() {
            @Override protected List<Object[]> doInBackground() throws Exception {
                return LoggerDAO.search(f);
            }

            @Override protected void done() {
                loading = false;
                try {
                    List<Object[]> rows = get();
                    int selected = table.getSelectedRow();
                    model.setRowCount(0);
                    for (Object[] r : rows) {
                        model.addRow(r);
                    }
                    if (selected >= 0 && selected < model.getRowCount()) {
                        table.setRowSelectionInterval(selected, selected);
                    }
                    lblCount.setText(rows.size() + (rows.size() == 1 ? " record" : " records"));
                    lblUpdated.setText("Auto-refreshing \u2022 last updated "
                            + LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("hh:mm:ss a")));
                    lblUpdated.setForeground(UI.GRAY);
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    lblUpdated.setText("Database error: " + cause.getMessage());
                    lblUpdated.setForeground(UI.ERROR_RED);
                }
            }
        }.execute();
    }
}
