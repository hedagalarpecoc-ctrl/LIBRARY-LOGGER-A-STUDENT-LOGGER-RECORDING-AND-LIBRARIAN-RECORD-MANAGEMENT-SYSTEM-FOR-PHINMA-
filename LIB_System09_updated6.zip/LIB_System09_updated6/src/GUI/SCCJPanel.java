package GUI;

/** SCCJ Department panel - shows only the attendance of students whose department is SCCJ. */
public class SCCJPanel extends AttendanceTablePanel {
    public SCCJPanel() {
        super("SCCJ", "SCCJ DEPARTMENT", "Attendance records of SCCJ students");
    }
}
