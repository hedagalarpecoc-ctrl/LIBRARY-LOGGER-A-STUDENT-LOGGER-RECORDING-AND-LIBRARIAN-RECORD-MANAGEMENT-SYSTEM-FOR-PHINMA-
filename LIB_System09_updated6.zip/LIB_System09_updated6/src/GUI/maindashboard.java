package GUI;

import database.LoggerDAO;
import database.StudentDAO;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import librarian_gui.Librarian;
import model.Staff;
import model.Student;

//...................................................In Left side  Student LOGBOOK
//The student types ONLY the student ID Number, then Time IN/ Time OUT.

//In Right side Staff LOGIN
//Admin/Librarian


public class maindashboard extends JFrame {

    private final JTextField txtStudentId = new UI.HintTextField("e.g. 02-2324-04499");
    private final UI.FlatButton btnTimeIn = UI.button("TIME IN", UI.GREEN);
    private final UI.FlatButton btnTimeOut = UI.button("TIME OUT", new Color(190, 120, 0));
    private final JLabel lblStatus = new JLabel(" ", SwingConstants.CENTER);
    private final JLabel lblStudentInfo = new JLabel(" ", SwingConstants.CENTER);
    private final JLabel lblClock = new JLabel(" ", SwingConstants.CENTER);
    private final Timer clockTimer;
    private final Timer clearTimer;

    public maindashboard() {
        super("Library Logbook");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1100, 660));
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout(14, 0));
        root.setBackground(UI.PAGE_BG);
        root.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        root.add(buildBrandPanel(), BorderLayout.WEST);
        root.add(buildRightSide(), BorderLayout.CENTER);
        setContentPane(root);

        clockTimer = new Timer(1000, e -> updateClock());
        clockTimer.start();
        updateClock();
        clearTimer = new Timer(6000, e -> clearStatus());
        clearTimer.setRepeats(false);

        // make sure every student's department matches their course (fills the blank ones)
        new SwingWorker<Integer, Void>() {
            @Override protected Integer doInBackground() throws Exception { return StudentDAO.syncDepartments(); }

            @Override protected void done() {
                try {
                    get();
                } catch (Exception ex) {
                    showStatus("Cannot reach the database. Is MySQL (XAMPP) running?", false);
                }
            }
        }.execute();
    }

    // ------------------------------------------------------------------ layout

    private JPanel buildBrandPanel() {
        JPanel p = new UI.RoundedPanel(new GridBagLayout(), 0, UI.GREEN, null);
        p.setPreferredSize(new Dimension(370, 0));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = GridBagConstraints.RELATIVE;
        c.insets = new Insets(2, 0, 2, 0);

        JLabel logo = new JLabel(UI.icon("/GUI/logo-removebg-preview (1).png"));
        c.insets = new Insets(0, 0, 14, 0);
        p.add(logo, c);
        c.insets = new Insets(2, 0, 2, 0);
        p.add(brandText("PHINMA", new Font("Serif", Font.BOLD | Font.ITALIC, 36), Color.WHITE), c);
        JPanel line = new UI.RoundedPanel(2, UI.GOLD, null);
        line.setPreferredSize(new Dimension(210, 3));
        c.insets = new Insets(6, 0, 10, 0);
        p.add(line, c);
        c.insets = new Insets(2, 0, 2, 0);
        p.add(brandText("CAGAYAN DE ORO", new Font("Serif", Font.BOLD | Font.ITALIC, 32), Color.WHITE), c);
        p.add(brandText("COLLEGE", new Font("Serif", Font.BOLD | Font.ITALIC, 32), Color.WHITE), c);
        return p;
    }

    private JLabel brandText(String text, Font font, Color color) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    private JPanel buildRightSide() {
        JPanel right = new UI.BackgroundPanel(0.35f, 0);
        right.setLayout(new GridBagLayout());

        JLabel title = new JLabel("LIBRARY LOGBOOK", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 40));
        title.setForeground(UI.GREEN);
        JLabel tag = new JLabel("Track \u2022 Manage \u2022 Create a Better Learning Development", SwingConstants.CENTER);
        tag.setFont(new Font("Serif", Font.ITALIC, 16));
        tag.setForeground(UI.GREEN);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.insets = new Insets(0, 0, 4, 0);
        right.add(title, c);
        c.gridy = 1;
        c.insets = new Insets(0, 0, 28, 0);
        right.add(tag, c);

        c.gridy = 2;
        c.gridwidth = 1;
        c.fill = GridBagConstraints.BOTH;
        c.insets = new Insets(0, 0, 0, 12);
        right.add(buildLogbookCard(), c);
        c.gridx = 1;
        c.insets = new Insets(0, 12, 0, 0);
        right.add(buildLoginCard(), c);
        return right;
    }

    private JPanel buildLogbookCard() {
        JPanel card = UI.card("STUDENT LOGBOOK");
        card.setPreferredSize(new Dimension(360, 440));

        JPanel body = new JPanel(new GridBagLayout());
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(16, 22, 18, 22));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;

        lblClock.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblClock.setForeground(UI.GRAY);
        c.gridy = 0; c.insets = new Insets(0, 0, 12, 0);
        body.add(lblClock, c);

        JLabel lbl = UI.label("Enter your Student ID Number");
        c.gridy = 1; c.insets = new Insets(0, 0, 6, 0);
        body.add(lbl, c);

        txtStudentId.setPreferredSize(new Dimension(100, 42));
        txtStudentId.setFont(new Font("SansSerif", Font.PLAIN, 16));
        c.gridy = 2; c.insets = new Insets(0, 0, 16, 0);
        body.add(txtStudentId, c);

        btnTimeIn.setPreferredSize(new Dimension(100, 42));
        btnTimeOut.setPreferredSize(new Dimension(100, 42));
        c.gridy = 3; c.gridwidth = 1; c.weightx = 0.5; c.insets = new Insets(0, 0, 0, 6);
        body.add(btnTimeIn, c);
        c.gridx = 1; c.insets = new Insets(0, 6, 0, 0);
        body.add(btnTimeOut, c);

        c.gridx = 0; c.gridwidth = 2; c.weightx = 1;
        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblStatus.setVerticalAlignment(SwingConstants.TOP);
        lblStatus.setPreferredSize(new Dimension(100, 48));     // fixed height so the card never jumps around
        lblStatus.setMinimumSize(new Dimension(100, 48));
        c.gridy = 4; c.insets = new Insets(16, 0, 0, 0);
        body.add(lblStatus, c);
        lblStudentInfo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblStudentInfo.setForeground(UI.GRAY);
        c.gridy = 5; c.insets = new Insets(2, 0, 0, 0);
        body.add(lblStudentInfo, c);
        c.gridy = 6; c.weighty = 1;
        body.add(Box.createVerticalGlue(), c);

        card.add(body, BorderLayout.CENTER);

        btnTimeIn.addActionListener(e -> logAttendance(true));
        btnTimeOut.addActionListener(e -> logAttendance(false));
        txtStudentId.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char ch = e.getKeyChar();
                if (!(Character.isDigit(ch) || ch == '-' || ch == KeyEvent.VK_BACK_SPACE || ch == KeyEvent.VK_DELETE
                        || ch == KeyEvent.VK_ENTER)) {
                    e.consume();                      // only digits and dashes can be typed
                }
            }
        });
        return card;
    }

    /** Staff card: Login, Forgot Password and Sign Up all live in StaffAccessPanel. */
    private JPanel buildLoginCard() {
        return new StaffAccessPanel(this::openDashboardFor);
    }

    // ------------------------------------------------------------------ student logbook

    private void updateClock() {
        lblClock.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy  \u2022  hh:mm:ss a")));
    }

    private void logAttendance(boolean isTimeIn) {
        final String id = txtStudentId.getText().trim();
        if (id.isEmpty()) {
            showStatus("Please enter your Student ID Number.", false);
            return;
        }
        if (!id.matches("^[0-9-]+$")) {
            showStatus("Invalid Student ID Number.", false);
            return;
        }
        btnTimeIn.setEnabled(false);
        btnTimeOut.setEnabled(false);
        clearStatus();

        new SwingWorker<LoggerDAO.LogResult, Void>() {
            @Override protected LoggerDAO.LogResult doInBackground() throws Exception {
                return isTimeIn ? LoggerDAO.timeIn(id) : LoggerDAO.timeOut(id);
            }

            @Override protected void done() {
                btnTimeIn.setEnabled(true);
                btnTimeOut.setEnabled(true);
                try {
                    LoggerDAO.LogResult r = get();
                    Student s = r.student;
                    lblStudentInfo.setText(s == null ? " " : s.getFullName() + "  \u2022  " + s.getCourse()
                            + (s.getDepartment() == null || s.getDepartment().isEmpty() ? "" : "  \u2022  " + s.getDepartment()));
                    if (r.isSuccess()) {
                        showStatus((isTimeIn ? "TIME IN" : "TIME OUT") + " successful \u2014 "
                                + r.time.format(LoggerDAO.TIME_FMT), true);
                        txtStudentId.setText("");
                    } else {
                        showStatus(r.message, false);
                    }
                } catch (Exception ex) {
                    Throwable t = ex.getCause() == null ? ex : ex.getCause();
                    showStatus("Database error: " + t.getMessage(), false);
                }
                clearTimer.restart();
            }
        }.execute();
    }

    private void showStatus(String msg, boolean ok) {
        lblStatus.setForeground(ok ? UI.GREEN : UI.ERROR_RED);
        String safe = msg.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        lblStatus.setText("<html><center>" + safe + "</center></html>");
    }

    private void clearStatus() {
        lblStatus.setText(" ");
        lblStudentInfo.setText(" ");
    }

    // ------------------------------------------------------------------ staff login

    /** Called by the Staff card after a successful login: Opens the Librarian dashboard directly. */
    private void openDashboardFor(Staff staff) {
        new Librarian(staff).setVisible(true);
        dispose();
    }

    @Override public void dispose() {
        clockTimer.stop();
        clearTimer.stop();
        super.dispose();
    }

    public static void main(String[] args) {
        UI.installLookAndFeel();
        EventQueue.invokeLater(() -> new maindashboard().setVisible(true));
    }
}