# Library Attendance Logger - what changed

## Run order
1. phpMyAdmin -> library_attendance_system -> SQL tab -> paste `sql/library_attendance_setup.sql` -> Go
2. NetBeans: Clean and Build (Shift+F11), then Run.
3. Staff login: admin / admin123  or  librarian / librarian123 (unchanged).

## New files
| File | Purpose |
|---|---|
| sql/library_attendance_setup.sql | removes duplicate students, UNIQUE Student ID Number, creates `attendance` table + foreign key |
| src/model/Student.java | student data object |
| src/database/StudentDAO.java | all student SQL (find, search, add, update, delete, department sync) |
| src/database/AttendanceDAO.java | Time In / Time Out rules + attendance queries/filters |
| src/GUI/UI.java | shared colours, buttons, table styling |
| src/GUI/AttendanceTablePanel.java | attendance table with search/sort/filter, auto-refresh every 5 s |
| src/GUI/StudentManagementPanel.java | student CRUD (Admin = full, Librarian = view + update) |
| src/GUI/DashboardFrame.java | shared sidebar window used by Admin and Librarian |

## Rewritten
maindashboard.java, Admin_Dashboard.java, Librarian.java, CAHSPanel/CEAPanel/CITEPanel/CMAPanel/COEPanel/SCCJPanel (each is now 3 lines),
department/Department.java (single course->department table), department/DepartmentMapper.java (delegates).

## Removed (replaced by the above)
AddStudentPanel, UpdateStudentPanel, LIBadd, student_auth (+ their .form files), and the .form files of
maindashboard, Admin_Dashboard, Librarian and the six department panels.
These screens are now written in code, so NetBeans opens them in Source view instead of the Design view.

## Round 2 (design polish + department views)
| File | Change |
|---|---|
| GUI/UI.java | Gold changed from bright lemon (204,204,0) to a muted academic gold (201,162,39); soft-gold table selection; drawn nav icons (clock / person / logout); `scaledIcon()` helper |
| GUI/DashboardFrame.java | New header bar (PHINMA COC logo, system name, logged-in user + role); sidebar with icons and gold active indicator |
| GUI/DepartmentView.java (new) | Each department (CAHS, CEA, CITE, CMA, COE, SCCJ) now has **Attendance** and **Students** views |
| GUI/StudentManagementPanel.java | Filter by department and course, sort options, department-only mode; the ID-format check is skipped when the ID is unchanged (so an existing ID like 02-2324-044996 no longer blocks updating that student) |
| database/StudentDAO.java | `findAll(keyword, department, course, sortIndex)` (prepared statement) |
| sql/library_attendance_setup.sql | Also fills the `department` column from the course |

Run order is unchanged (run the SQL first, then Clean and Build).

## Round 3 (staff accounts, rounded design, your library_logger database)
| File | Change |
|---|---|
| sql/staff_tbl.sql (new) | `staff_tbl` for staff accounts (the program also creates it by itself on first use) |
| model/Staff.java (new) | staff account object |
| database/StaffDAO.java (new) | login, sign up, find account, reset password (salted PBKDF2 hashes, no plain text) |
| GUI/StaffAccessPanel.java (new) | Staff card with 3 screens: Login (+ Forgot Password? / Sign Up links), Forgot Password, Sign Up |
| GUI/UI.java | RoundedPanel, RoundedTextField, RoundedPasswordField, LinkLabel, Card, rounded BackgroundPanel; buttons use the same radius |
| GUI/maindashboard.java | rounded blocks, Staff card = StaffAccessPanel; login now checks staff_tbl |
| GUI/DashboardFrame.java, Admin_Dashboard.java, librarian_gui/Librarian.java | rounded header / sidebar / content; header shows the logged-in staff |
| GUI/StudentManagementPanel.java, AttendanceTablePanel.java | rounded form + search panels |
| database/StudentDAO.java, LoggerDAO.java, department/Department.java | now use student_tbl, course_tbl, dept_tbl, logger_tbl; department comes from course_tbl/dept_tbl |

## Round 4 (Senior High School button)
| File | Change |
|---|---|
| department/Department.java | `SHS` added to `DEPARTMENTS` (also appears in the department filters) |
| GUI/SHSPanel.java (new) | SHS attendance panel, same pattern as CITEPanel etc. |
| GUI/DashboardFrame.java | Full-width **SENIOR HIGH SCHOOL** button under the college grid, same style/behaviour; opens the usual Attendance / Students views |
| sql/shs_departments.sql (new) | Adds SHS to `dept_tbl` and the strands ABM, TVL, HUMSS, GAS, STEM to `course_tbl` (run once in phpMyAdmin) |
