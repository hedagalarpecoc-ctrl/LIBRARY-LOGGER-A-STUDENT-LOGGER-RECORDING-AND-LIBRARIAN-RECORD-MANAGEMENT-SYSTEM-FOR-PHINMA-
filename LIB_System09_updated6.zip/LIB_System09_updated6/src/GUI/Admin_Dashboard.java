package GUI;

import model.Staff;

/** Admin: full student CRUD + all attendance + every department panel. */
public class Admin_Dashboard extends DashboardFrame {

    public Admin_Dashboard() {
        this(null);
    }

    /** @param staff the account that logged in (shown in the header); may be null. */
    public Admin_Dashboard(Staff staff) {
        super("ADMIN", true, staff);
    }

    public static void main(String[] args) {
        UI.installLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Admin_Dashboard().setVisible(true));
    }
}
