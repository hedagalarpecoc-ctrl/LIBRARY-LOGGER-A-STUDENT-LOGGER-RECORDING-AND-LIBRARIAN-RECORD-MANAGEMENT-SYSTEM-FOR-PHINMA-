package GUI;

import java.awt.*;
import javax.swing.*;

/**
 * One department screen with two views the staff can switch between:
 *   Attendance - that department's attendance records (auto-refreshing)
 *   Students   - that department's registered students (Admin: full CRUD, Librarian: view + update)
 */
public class DepartmentView extends JPanel {

    private final CardLayout cards = new CardLayout();
    private final JPanel body = new JPanel(cards);
    private final UI.FlatButton btnAttendance = UI.button("Attendance", UI.LIGHT_GREEN);
    private final UI.FlatButton btnStudents = UI.button("Students", UI.LIGHT_GREEN);
    private final StudentManagementPanel students;

    public DepartmentView(boolean fullAccess, String dept, AttendanceTablePanel attendance) {
        setLayout(new BorderLayout());
        setOpaque(false);
        body.setOpaque(false);
        students = new StudentManagementPanel(fullAccess, dept);
        body.add(attendance, "att");
        body.add(students, "stu");

        JPanel tabs = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        tabs.setOpaque(false);
        tabs.setBorder(BorderFactory.createEmptyBorder(14, 24, 0, 24));
        tabs.add(btnAttendance);
        tabs.add(btnStudents);
        add(tabs, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);

        btnAttendance.addActionListener(e -> show("att"));
        btnStudents.addActionListener(e -> show("stu"));
        show("att");
    }

    private void show(String card) {
        cards.show(body, card);
        btnAttendance.setActive(card.equals("att"));
        btnStudents.setActive(card.equals("stu"));
        if (card.equals("stu")) {
            students.reload();           // pick up edits made elsewhere
        }
    }
}
