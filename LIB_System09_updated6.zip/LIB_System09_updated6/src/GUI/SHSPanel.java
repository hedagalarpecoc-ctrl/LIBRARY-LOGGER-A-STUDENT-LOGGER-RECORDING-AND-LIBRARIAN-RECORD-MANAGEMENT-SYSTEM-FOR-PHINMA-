package GUI;

/** Senior High School panel - shows only the attendance of students whose strand (course) belongs to SHS. */
public class SHSPanel extends AttendanceTablePanel {
    public SHSPanel() {
        super("SHS", "SENIOR HIGH SCHOOL", "Attendance records of Senior High School students (ABM, TVL, HUMSS, GAS, STEM)");
    }
}
