package GUI;

import database.AdminDAO;
import database.StaffDAO;
import java.awt.*;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import javax.swing.*;
import model.admin;
import model.Staff;

public class StaffAccessPanel extends UI.Card {

    private static final String LOGIN = "login", FORGOT = "forgot", SIGNUP = "signup";
    private static final int MIN_PASSWORD = 6;

    private final CardLayout screens = new CardLayout();
    private final JPanel body = new JPanel(screens);
    private final Consumer<Staff> onLogin;

    // login
    private final JTextField txtUser = new UI.RoundedTextField("Username", 0);
    private final JPasswordField txtPass = new UI.RoundedPasswordField("Password");
    private final UI.FlatButton btnLogin = UI.button("LOGIN", UI.GREEN);

    // forgot password
    private final JTextField txtFindAccount = new UI.RoundedTextField("Registered username or email", 0);
    private final JPasswordField txtNewPass = new UI.RoundedPasswordField("New Password");
    private final JPasswordField txtNewConfirm = new UI.RoundedPasswordField("Confirm Password");
    private final UI.FlatButton btnFind = UI.button("CONTINUE", UI.GREEN);
    private final UI.FlatButton btnReset = UI.button("RESET PASSWORD", UI.GREEN);
    private final JLabel lblForgotHint = new JLabel();
    private String verifiedAccount;             // set once the account has been found

    // sign up
    private final JTextField txtEmail = new UI.RoundedTextField("Email", 0);
    private final JTextField txtLastname = new UI.RoundedTextField("Lastname", 0);
    private final JTextField txtFirstname = new UI.RoundedTextField("Firstname", 0);
    private final JTextField txtNewUser = new UI.RoundedTextField("Username", 0);
    private final JPasswordField txtSignPass = new UI.RoundedPasswordField("Password");
    private final JPasswordField txtSignConfirm = new UI.RoundedPasswordField("Confirm Password");
    private final UI.FlatButton btnSignUp = UI.button("SIGN UP", UI.GREEN);

    public StaffAccessPanel(Consumer<Staff> onLogin) {
        super("STAFF LOGIN");
        this.onLogin = onLogin;
        setPreferredSize(new Dimension(360, 440));
        body.setOpaque(false);
        body.add(buildLogin(), LOGIN);
        body.add(buildForgot(), FORGOT);
        body.add(buildSignUp(), SIGNUP);
        add(body, BorderLayout.CENTER);
        show(LOGIN);
    }

    // ------------------------------------------------------------------ screens

    private void show(String screen) {
        switch (screen) {
            case FORGOT:
                setTitle("FORGOT PASSWORD");
                resetForgotForm();
                break;
            case SIGNUP:
                setTitle("STAFF SIGN UP");
                resetSignUpForm();
                break;
            default:
                setTitle("LOG IN");
                txtPass.setText("");
                break;
        }
        screens.show(body, screen);
        revalidate();
        repaint();
    }

    private JPanel newBody() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(16, 22, 14, 22));
        return p;
    }

    private GridBagConstraints constraints() {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = GridBagConstraints.RELATIVE;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        return c;
    }

    private void field(JPanel p, GridBagConstraints c, JComponent f, int height, int gapBelow) {
        f.setPreferredSize(new Dimension(100, height));
        c.insets = new Insets(0, 0, gapBelow, 0);
        p.add(f, c);
    }

    private JPanel centeredRow(JComponent... parts) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        row.setOpaque(false);
        for (JComponent part : parts) {
            row.add(part);
        }
        return row;
    }

    private JLabel small(String text, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.PLAIN, 13));
        l.setForeground(color);
        return l;
    }

    private JComponent filler(GridBagConstraints c) {
        JComponent glue = (JComponent) Box.createVerticalGlue();
        c.weighty = 1;
        return glue;
    }

    // ---- login

    private JPanel buildLogin() {
        JPanel p = newBody();
        GridBagConstraints c = constraints();

        JLabel note = new JLabel("For Administrator and Librarian only.");
        note.setFont(new Font("Serif", Font.PLAIN, 14));
        c.insets = new Insets(0, 0, 16, 0);
        p.add(note, c);

        field(p, c, txtUser, 42, 12);

        // Gi-embed ang Show/Hide button sulod sa password field
        JPasswordField passEmbedded = createEmbeddedPasswordToggle(txtPass);
        field(p, c, passEmbedded, 42, 8);

        JPanel forgotRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        forgotRow.setOpaque(false);
        forgotRow.add(new UI.LinkLabel("Forgot Password?", () -> show(FORGOT)));
        c.insets = new Insets(0, 0, 14, 0);
        p.add(forgotRow, c);

        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 16));
        field(p, c, btnLogin, 44, 14);

        c.insets = new Insets(0, 0, 0, 0);
        p.add(centeredRow(small("Don't have an account?", UI.GRAY), new UI.LinkLabel("Sign Up", () -> show(SIGNUP))), c);

        p.add(filler(c), c);

        btnLogin.addActionListener(e -> doLogin());
        txtPass.addActionListener(e -> doLogin());
        txtUser.addActionListener(e -> txtPass.requestFocusInWindow());
        return p;
    }

    private void doLogin() {
        String user = txtUser.getText().trim();
        char[] pass = txtPass.getPassword();
        if (user.isEmpty() || pass.length == 0) {
            UI.warn(this, "Please enter your username and password.");
            return;
        }

        async(() -> {
            admin adminAcc = AdminDAO.authenticate(user, pass);
            if (adminAcc != null) {
                return adminAcc; 
            }
            return StaffDAO.authenticate(user, pass); 
        }, result -> {
            if (result == null) {
                UI.error(this, "Invalid Username or Password!");
                txtPass.setText("");
            } else if (result instanceof admin) {
                // Pag Admin account ang nag-log in
                new Admin_Dashboard().setVisible(true);

                Window topWindow = SwingUtilities.getWindowAncestor(this);
                if (topWindow != null) {
                    topWindow.dispose();
                }
            } else if (result instanceof Staff) {
                // Pag Librarian/Staff account ang nag-login
                onLogin.accept((Staff) result);
            }
        });
    }

    // ---- forgot password

    private JPanel buildForgot() {
        JPanel p = newBody();
        GridBagConstraints c = constraints();

        lblForgotHint.setFont(new Font("Serif", Font.PLAIN, 14));
        c.insets = new Insets(0, 0, 14, 0);
        p.add(lblForgotHint, c);

        field(p, c, txtFindAccount, 42, 12);
        field(p, c, txtNewPass, 42, 12);
        field(p, c, txtNewConfirm, 42, 16);
        btnFind.setFont(new Font("SansSerif", Font.BOLD, 15));
        btnReset.setFont(new Font("SansSerif", Font.BOLD, 15));
        field(p, c, btnFind, 44, 0);
        field(p, c, btnReset, 44, 0);

        c.insets = new Insets(14, 0, 0, 0);
        p.add(centeredRow(new UI.LinkLabel("\u2190 Back to Login", () -> show(LOGIN))), c);
        p.add(filler(c), c);

        btnFind.addActionListener(e -> findAccount());
        txtFindAccount.addActionListener(e -> findAccount());
        btnReset.addActionListener(e -> resetPassword());
        txtNewConfirm.addActionListener(e -> resetPassword());
        return p;
    }

    /** Back to step 1 (account not found yet). */
    private void resetForgotForm() {
        verifiedAccount = null;
        txtFindAccount.setText("");
        txtFindAccount.setEditable(true);
        txtNewPass.setText("");
        txtNewConfirm.setText("");
        txtNewPass.setVisible(false);
        txtNewConfirm.setVisible(false);
        btnReset.setVisible(false);
        btnFind.setVisible(true);
        lblForgotHint.setText("Enter your registered username or email.");
    }

    private void findAccount() {
        String account = txtFindAccount.getText().trim();
        if (account.isEmpty()) {
            UI.warn(this, "Please enter your registered username or email.");
            return;
        }
        async(() -> StaffDAO.findByUsernameOrEmail(account), staff -> {
            if (staff == null) {
                UI.error(this, "Invalid account. No staff account matches \"" + account + "\".");
                return;
            }
            verifiedAccount = account;                 // step 2: let them choose a new password
            txtFindAccount.setEditable(false);
            btnFind.setVisible(false);
            txtNewPass.setVisible(true);
            txtNewConfirm.setVisible(true);
            btnReset.setVisible(true);
            lblForgotHint.setText("Account found. Create a new password.");
            txtNewPass.requestFocusInWindow();
            revalidate();
            repaint();
        });
    }

    private void resetPassword() {
        if (verifiedAccount == null) {
            findAccount();
            return;
        }
        char[] pass = txtNewPass.getPassword();
        char[] confirm = txtNewConfirm.getPassword();
        if (pass.length == 0 || confirm.length == 0) {
            UI.warn(this, "Please fill in the New Password and Confirm Password fields.");
            return;
        }
        if (!java.util.Arrays.equals(pass, confirm)) {
            UI.error(this, "The passwords do not match.");
            txtNewConfirm.setText("");
            txtNewConfirm.requestFocusInWindow();
            return;
        }
        if (pass.length < MIN_PASSWORD) {
            UI.warn(this, "The password must be at least " + MIN_PASSWORD + " characters long.");
            return;
        }
        final String account = verifiedAccount;
        async(() -> StaffDAO.resetPassword(account, pass), ok -> {
            if (ok) {
                UI.info(this, "Your password has been reset successfully.\nYou can now log in with your new password.");
                txtUser.setText(account);
                show(LOGIN);
                txtPass.requestFocusInWindow();
            } else {
                UI.error(this, "Invalid account. The account could not be found any more.");
                resetForgotForm();
            }
        });
    }

    // ---- sign up

    private JPanel buildSignUp() {
        JPanel p = newBody();
        p.setBorder(BorderFactory.createEmptyBorder(8, 22, 6, 22));
        GridBagConstraints c = constraints();

        field(p, c, txtEmail, 34, 6);
        field(p, c, txtLastname, 34, 6);
        field(p, c, txtFirstname, 34, 6);
        field(p, c, txtNewUser, 34, 6);
        field(p, c, createEmbeddedPasswordToggle(txtSignPass), 34, 6);
        field(p, c, createEmbeddedPasswordToggle(txtSignConfirm), 34, 10);
        btnSignUp.setFont(new Font("SansSerif", Font.BOLD, 15));
        field(p, c, btnSignUp, 38, 0);

        c.insets = new Insets(6, 0, 0, 0);
        p.add(centeredRow(new UI.LinkLabel("\u2190 Back to Login", () -> show(LOGIN))), c);
        p.add(filler(c), c);

        btnSignUp.addActionListener(e -> signUp());
        txtSignConfirm.addActionListener(e -> signUp());
        return p;
    }

    private void resetSignUpForm() {
        txtEmail.setText("");
        txtLastname.setText("");
        txtFirstname.setText("");
        txtNewUser.setText("");
        txtSignPass.setText("");
        txtSignConfirm.setText("");
    }

    private void signUp() {
        final String email = txtEmail.getText().trim();
        final String lastname = txtLastname.getText().trim();
        final String firstname = txtFirstname.getText().trim();
        final String username = txtNewUser.getText().trim();
        final char[] pass = txtSignPass.getPassword();
        final char[] confirm = txtSignConfirm.getPassword();

        if (email.isEmpty() || lastname.isEmpty() || firstname.isEmpty() || username.isEmpty() || pass.length == 0 || confirm.length == 0) {
            UI.warn(this, "Please fill in all the fields.");
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            UI.error(this, "Please enter a valid email address.");
            return;
        }

        if (username.contains(" ")) {
            UI.error(this, "The username cannot contain spaces.");
            return;
        }
        if (!java.util.Arrays.equals(pass, confirm)) {
            UI.error(this, "The passwords do not match.");
            txtSignConfirm.setText("");
            return;
        }
        if (pass.length < MIN_PASSWORD) {
            UI.warn(this, "The password must be at least " + MIN_PASSWORD + " characters long.");
            return;
        }

        this.<Object>async(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                try {
                    return StaffDAO.register(email, lastname, firstname, username, pass);
                } catch (Exception ex) {
                    return ex;
                }
            }
        }, result -> {
            if (result instanceof StaffDAO.DuplicateStaffException) {
                UI.error(this, ((Exception) result).getMessage());
                return;
            } else if (result instanceof Exception) {
                UI.error(this, "Failed to create account: " + ((Exception) result).getMessage());
                return;
            }

            // Direktang mag-navigate papuntang Librarian Dashboard kapag matagumpay ang sign up
            if (result instanceof Staff) {
                Staff newStaff = (Staff) result;
                UI.info(this, "Account created successfully! Redirecting to Librarian Dashboard...");
                resetSignUpForm();
                
                onLogin.accept(newStaff);
            }
        });
    }

    // Helper method para ilagay ang Show/Hide button sa loob ng JPasswordField
    private JPasswordField createEmbeddedPasswordToggle(JPasswordField passField) {
        passField.setLayout(new BorderLayout());

        final char echoChar = passField.getEchoChar();

        JToggleButton toggleBtn = new JToggleButton("Show");
        toggleBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
        toggleBtn.setForeground(UI.GREEN);
        toggleBtn.setFocusPainted(false);
        toggleBtn.setContentAreaFilled(false);
        toggleBtn.setBorderPainted(false);
        toggleBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toggleBtn.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 12));

        toggleBtn.addActionListener(e -> {
            if (toggleBtn.isSelected()) {
                passField.setEchoChar((char) 0);
                toggleBtn.setText("Hide");
            } else {
                passField.setEchoChar(echoChar);
                toggleBtn.setText("Show");
            }
        });

        passField.add(toggleBtn, BorderLayout.EAST);

        Insets current = passField.getMargin();
        int top = current != null ? current.top : 0;
        int left = current != null ? current.left : 10;
        int bottom = current != null ? current.bottom : 0;
        passField.setMargin(new Insets(top, left, bottom, 50)); 

        return passField;
    }

    // ------------------------------------------------------------------ database helper

    /** Runs a database job off the screen thread (so the window never freezes), then hands the result back. */
    private <T> void async(Callable<T> job, Consumer<T> done) {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return job.call(); }

            @Override protected void done() {
                setCursor(Cursor.getDefaultCursor());
                try {
                    done.accept(get());
                } catch (Exception ex) {
                    Throwable t = ex.getCause() == null ? ex : ex.getCause();
                    UI.error(StaffAccessPanel.this, "Database error: " + t.getMessage()
                        + "\nIs MySQL (XAMPP) running and is the database 'library_logger' there?");
                }
            }
        }.execute();
    }
}