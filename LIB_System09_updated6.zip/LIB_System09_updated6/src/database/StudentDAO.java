package database;

import department.Department;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Student;

/**
 * All SQL for students. Works with YOUR library_logger tables:
 *   student_tbl (student_id, studentid_number, lastname, firstname, middle_initial, course_id)
 *   course_tbl  (course_id, course_code, course_name, department_id)
 *   dept_tbl    (department_id, department_code, department_name)
 * The department is not stored in student_tbl - it comes from the student's course.
 */
public class StudentDAO {

    private static final String COURSE_COL = "c." + Department.COURSE_COLUMN;

    private static final String SELECT =
        "SELECT s.student_id, s.studentid_number, s.lastname, s.firstname, s.middle_initial, "
      + COURSE_COL + " AS course, d.department_code AS department "
      + "FROM student_tbl s "
      + "LEFT JOIN course_tbl c ON c.course_id = s.course_id "
      + "LEFT JOIN dept_tbl d ON d.department_id = c.department_id ";

    private static Student map(ResultSet rs) throws SQLException {
        return new Student(
            rs.getInt("student_id"),
            rs.getString("studentid_number"),
            rs.getString("lastname"),
            rs.getString("firstname"),
            rs.getString("middle_initial"),
            rs.getString("course"),
            rs.getString("department"));
    }

    /** Used by the Main Dashboard: look a student up by the Student ID Number they typed. */
    public static Student findByIdNumber(String idNumber) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            return findByIdNumber(con, idNumber);
        }
    }

    /** Same, but on a connection the caller already has open (used inside a transaction). */
    static Student findByIdNumber(Connection con, String idNumber) throws SQLException {
        try (PreparedStatement pst = con.prepareStatement(SELECT + "WHERE s.studentid_number = ?")) {
            pst.setString(1, idNumber.trim());
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** All students, optionally filtered by ID number / last name / first name. */
    public static List<Student> findAll(String keyword) throws SQLException {
        return findAll(keyword, null, null, 0);
    }

    public static final String[] SORT_OPTIONS = {
        "Last name: A-Z", "Last name: Z-A", "Student ID Number", "Course", "Department"
    };

    /** Students filtered by keyword, department and course (null/"" = no filter), sorted by SORT_OPTIONS[sortIndex]. */
    public static List<Student> findAll(String keyword, String department, String course, int sortIndex)
            throws SQLException {
        StringBuilder sql = new StringBuilder(SELECT + "WHERE "
            + "(s.studentid_number LIKE ? OR s.lastname LIKE ? OR s.firstname LIKE ? "
            + "OR CONCAT(s.firstname,' ',s.lastname) LIKE ? OR CONCAT(s.lastname,', ',s.firstname) LIKE ?)");
        List<String> params = new ArrayList<>();
        String like = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        for (int i = 0; i < 5; i++) {
            params.add(like);
        }
        if (department != null && !department.isEmpty()) {
            sql.append(" AND d.department_code = ?");
            params.add(department);
        }
        if (course != null && !course.isEmpty()) {
            sql.append(" AND ").append(COURSE_COL).append(" = ?");
            params.add(course);
        }
        switch (sortIndex) {
            case 1:  sql.append(" ORDER BY s.lastname DESC, s.firstname DESC"); break;
            case 2:  sql.append(" ORDER BY s.studentid_number ASC"); break;
            case 3:  sql.append(" ORDER BY ").append(COURSE_COL).append(" ASC, s.lastname ASC, s.firstname ASC"); break;
            case 4:  sql.append(" ORDER BY d.department_code ASC, s.lastname ASC, s.firstname ASC"); break;
            default: sql.append(" ORDER BY s.lastname ASC, s.firstname ASC"); break;
        }
        List<Student> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setString(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    /** course_tbl.course_id for the course text shown in the program (course code). */
    private static int courseId(Connection con, String course) throws SQLException {
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT course_id FROM course_tbl WHERE " + Department.COURSE_COLUMN + " = ?")) {
            pst.setString(1, course);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        throw new SQLException("Course \"" + course + "\" does not exist in course_tbl.");
    }

    private static boolean idNumberTaken(Connection con, String idNumber, int exceptStudentId) throws SQLException {
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT 1 FROM student_tbl WHERE studentid_number = ? AND student_id <> ?")) {
            pst.setString(1, idNumber);
            pst.setInt(2, exceptStudentId);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Inserts a student. The department follows the course automatically. */
    public static void insert(Student s) throws SQLException, DuplicateStudentException {
        s.setDepartment(Department.getDepartment(s.getCourse()));
        String sql = "INSERT INTO student_tbl (studentid_number, lastname, firstname, middle_initial, course_id) "
                   + "VALUES (?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection()) {
            if (idNumberTaken(con, s.getIdNumber(), 0)) {
                throw new DuplicateStudentException(s.getIdNumber());
            }
            try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                pst.setString(1, s.getIdNumber());
                pst.setString(2, s.getLastName());
                pst.setString(3, s.getFirstName());
                pst.setString(4, s.getMiddleInitial());
                pst.setInt(5, courseId(con, s.getCourse()));
                pst.executeUpdate();
                try (ResultSet keys = pst.getGeneratedKeys()) {
                    if (keys.next()) {
                        s.setId(keys.getInt(1));
                    }
                }
            }
        } catch (SQLIntegrityConstraintViolationException ex) {
            throw new DuplicateStudentException(s.getIdNumber());
        }
    }

    public static void update(Student s) throws SQLException, DuplicateStudentException {
        s.setDepartment(Department.getDepartment(s.getCourse()));
        String sql = "UPDATE student_tbl SET studentid_number=?, lastname=?, firstname=?, middle_initial=?, "
                   + "course_id=? WHERE student_id=?";
        try (Connection con = DBConnection.getConnection()) {
            if (idNumberTaken(con, s.getIdNumber(), s.getId())) {
                throw new DuplicateStudentException(s.getIdNumber());
            }
            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, s.getIdNumber());
                pst.setString(2, s.getLastName());
                pst.setString(3, s.getFirstName());
                pst.setString(4, s.getMiddleInitial());
                pst.setInt(5, courseId(con, s.getCourse()));
                pst.setInt(6, s.getId());
                pst.executeUpdate();
            }
        } catch (SQLIntegrityConstraintViolationException ex) {
            throw new DuplicateStudentException(s.getIdNumber());
        }
    }

    /** Deletes the student together with their logger_tbl rows (one transaction, so nothing is left half-deleted). */
    public static boolean delete(int studentId) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement pst = con.prepareStatement("DELETE FROM logger_tbl WHERE student_id = ?")) {
                    pst.setInt(1, studentId);
                    pst.executeUpdate();
                }
                boolean removed;
                try (PreparedStatement pst = con.prepareStatement("DELETE FROM student_tbl WHERE student_id = ?")) {
                    pst.setInt(1, studentId);
                    removed = pst.executeUpdate() > 0;
                }
                con.commit();
                return removed;
            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            }
        }
    }

    /**
     * Kept so the Main Dashboard start-up check still works. In your database the department is not stored
     * on the student any more (it comes from course_tbl), so there is nothing to fix - this just makes sure the
     * database can be reached (it throws when it cannot) and re-reads the course list.
     */
    public static int syncDepartments() throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("SELECT 1")) {
            pst.executeQuery().close();
        }
        Department.reload();
        return 0;
    }

    public static class DuplicateStudentException extends Exception {
        public DuplicateStudentException(String idNumber) {
            super("Student ID Number " + idNumber + " is already registered.");
        }
    }
}
