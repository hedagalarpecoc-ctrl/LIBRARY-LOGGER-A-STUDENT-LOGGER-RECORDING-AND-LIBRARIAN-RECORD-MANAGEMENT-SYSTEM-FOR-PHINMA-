-- =====================================================================
--  Staff accounts (Staff Login / Sign Up / Forgot Password)
--  Database: library_logger   ->  phpMyAdmin > library_logger > SQL tab > paste > Go
--
--  OPTIONAL: the program creates this table by itself the first time the
--  Staff Login is used. Run this only if you want to see the table first.
--  (The admin / librarian accounts are added by the program, because their
--  passwords must be stored as hashes, not as plain text.)
-- =====================================================================
USE library_logger;

CREATE TABLE IF NOT EXISTS staff_tbl (
    staff_id       INT          NOT NULL AUTO_INCREMENT,
    staff_number   VARCHAR(30)  NOT NULL,                 -- "Staff ID" on the sign-up form
    full_name      VARCHAR(100) NOT NULL,
    username       VARCHAR(50)  NOT NULL,
    email          VARCHAR(100) NULL,
    password_hash  VARCHAR(255) NOT NULL,                 -- salted PBKDF2 hash, never plain text
    role           VARCHAR(20)  NOT NULL DEFAULT 'LIBRARIAN',   -- ADMIN or LIBRARIAN
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (staff_id),
    UNIQUE KEY uq_staff_number (staff_number),
    UNIQUE KEY uq_staff_username (username),
    UNIQUE KEY uq_staff_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Only if phpMyAdmin > logger_tbl > Structure shows that time_out is NOT NULL,
-- un-comment the next line (a student who has not timed out yet has no time_out):
-- ALTER TABLE logger_tbl MODIFY time_out TIME NULL;
