package GUI;

import database.StudentDAO;
import department.Department;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import model.Student;

/**
 * Student records: view / add / update / delete in one screen.
 *   fullAccess == true   -> Admin      (Add, Update, Delete, can edit the Student ID Number)
 *   fullAccess == false  -> Librarian  (view + Update only; Student ID Number is read-only)
 */
public class StudentManagementPanel extends JPanel {

    private static final String[] COLUMNS = {"Student ID Number", "Last Name", "First Name", "M.I.", "Course", "Department"};
    private static final String ID_PATTERN = "^\\d{2,4}-\\d{4}-\\d{4,5}$";   // e.g. 02-2324-04499
    private static final String NAME_PATTERN = "^[\\p{L}][\\p{L} .'\\-]*$";

    private final boolean fullAccess;
    private final String fixedDepartment;      // non-null = this panel lists one department only
    private final DefaultTableModel model;
    private final JTable table;
    private List<Student> students = new java.util.ArrayList<>();
    private Student selected;      // student currently loaded in the form (null = none)

    private final JTextField txtId = UI.textField(14);
    private final JTextField txtLast = UI.textField(14);
    private final JTextField txtFirst = UI.textField(14);
    private final JTextField txtMI = UI.textField(3);
    private final JComboBox<String> cbCourse;
    private final JLabel lblDept = new JLabel("\u2014");
    private final JTextField txtSearch = UI.textField(20);
    private final JLabel lblCount = new JLabel(" ");
    private final JComboBox<String> cbFilterDept = UI.combo(deptFilterItems());
    private final JComboBox<String> cbFilterCourse = UI.combo(new String[] {"All Courses"});
    private final JComboBox<String> cbSort = UI.combo(database.StudentDAO.SORT_OPTIONS);
    private boolean suppressFilter;
    private final JButton btnAdd = UI.button("Add Student", UI.GREEN);
    private final JButton btnUpdate = UI.button("Update", UI.LIGHT_GREEN);
    private final JButton btnDelete = UI.button("Delete", UI.ERROR_RED);
    private final JButton btnClear = UI.button("Clear", UI.GRAY);
    private final Timer debounce;

    private static String[] deptFilterItems() {
        String[] items = new String[Department.DEPARTMENTS.length + 1];
        items[0] = "All Departments";
        System.arraycopy(Department.DEPARTMENTS, 0, items, 1, Department.DEPARTMENTS.length);
        return items;
    }

    public StudentManagementPanel(boolean fullAccess) {
        this(fullAccess, null);
    }

    public StudentManagementPanel(boolean fullAccess, String fixedDepartment) {
        this.fullAccess = fullAccess;
        this.fixedDepartment = fixedDepartment;
        setLayout(new BorderLayout(0, 14));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));

        JLabel title = new JLabel(fixedDepartment == null ? "STUDENT RECORDS" : fixedDepartment + " STUDENTS");
        title.setFont(UI.TITLE);
        title.setForeground(UI.GREEN);
        JLabel sub = new JLabel(fullAccess
            ? "Add, view, update and delete registered students. The department is assigned automatically from the course."
            : "View student records and update their details. (Adding and deleting is done by the Admin.)");
        sub.setFont(UI.BODY);
        sub.setForeground(UI.GRAY);
        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.add(title);
        head.add(Box.createVerticalStrut(2));
        head.add(sub);

        // ---- form
        String[] courses = new String[Department.getCourses().size() + 1];
        courses[0] = "Select Course";
        for (int i = 0; i < courses.length - 1; i++) {
            courses[i + 1] = Department.getCourses().get(i);
        }
        cbCourse = UI.combo(courses);
        lblDept.setFont(UI.HEADING);
        lblDept.setForeground(UI.GREEN);
        txtMI.setColumns(3);
        ((javax.swing.text.AbstractDocument) txtMI.getDocument()).setDocumentFilter(new javax.swing.text.DocumentFilter() {
            @Override public void replace(FilterBypass fb, int off, int len, String text, javax.swing.text.AttributeSet a)
                    throws javax.swing.text.BadLocationException {
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String next = cur.substring(0, off) + (text == null ? "" : text) + cur.substring(off + len);
                if (next.length() <= 1) {                                   // M.I. = one letter only
                    super.replace(fb, off, len, text == null ? null : text.toUpperCase(), a);
                }
            }
        });
        txtId.setEditable(fullAccess);

        JPanel form = new UI.RoundedPanel(new GridBagLayout(), UI.CARD_RADIUS, Color.WHITE, UI.BORDER);   // rounded form container
        form.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 6, 4, 10);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridy = 0;
        c.gridx = 0; form.add(UI.label("Student ID Number"), c);
        c.gridx = 1; form.add(UI.label("Last Name"), c);
        c.gridx = 2; form.add(UI.label("First Name"), c);
        c.gridx = 3; form.add(UI.label("M.I."), c);
        c.gridy = 1;
        c.gridx = 0; form.add(txtId, c);
        c.gridx = 1; form.add(txtLast, c);
        c.gridx = 2; form.add(txtFirst, c);
        c.gridx = 3; form.add(txtMI, c);
        c.gridy = 2;
        c.gridx = 0; c.gridwidth = 2; form.add(UI.label("Course"), c);
        c.gridx = 2; c.gridwidth = 2; form.add(UI.label("Department (automatic)"), c);
        c.gridy = 3;
        c.gridx = 0; c.gridwidth = 2; form.add(cbCourse, c);
        c.gridx = 2; c.gridwidth = 2; form.add(lblDept, c);

        // invisible filler column so the form hugs the left edge instead of floating in the middle
        GridBagConstraints filler = new GridBagConstraints();
        filler.gridx = 4;
        filler.gridy = 0;
        filler.weightx = 1;
        form.add(Box.createHorizontalGlue(), filler);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        if (fullAccess) {
            buttons.add(btnAdd);
        }
        buttons.add(btnUpdate);
        if (fullAccess) {
            buttons.add(btnDelete);
        }
        buttons.add(btnClear);
        c.gridy = 4; c.gridx = 0; c.gridwidth = 4; c.insets = new Insets(12, 6, 0, 10);
        form.add(buttons, c);

        JPanel north = new JPanel(new BorderLayout(0, 12));
        north.setOpaque(false);
        north.add(head, BorderLayout.NORTH);
        north.add(form, BorderLayout.CENTER);
        add(north, BorderLayout.NORTH);

        // ---- table + search
        model = new DefaultTableModel(COLUMNS, 0) {
            @Override public boolean isCellEditable(int r, int col) { return false; }
        };
        table = new JTable(model);
        UI.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        int[] widths = {150, 140, 140, 50, 240, 90};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        row1.setOpaque(false);
        row1.add(UI.label("Search:"));
        row1.add(txtSearch);
        lblCount.setFont(UI.LABEL);
        lblCount.setForeground(UI.GREEN);
        row1.add(Box.createHorizontalStrut(12));
        row1.add(lblCount);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        row2.setOpaque(false);
        if (fixedDepartment == null) {
            row2.add(UI.label("Department:"));
            row2.add(cbFilterDept);
        }
        row2.add(UI.label("Course:"));
        cbFilterCourse.setPreferredSize(new Dimension(230, 34));
        row2.add(cbFilterCourse);
        row2.add(UI.label("Sort by:"));
        row2.add(cbSort);
        fillFilterCourses();

        JPanel searchRow = new UI.RoundedPanel(null, UI.CARD_RADIUS - 4, Color.WHITE, UI.BORDER);   // rounded search panel
        searchRow.setLayout(new BoxLayout(searchRow, BoxLayout.Y_AXIS));
        searchRow.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        searchRow.add(row1);
        searchRow.add(row2);

        JPanel center = new JPanel(new BorderLayout(0, 8));
        center.setOpaque(false);
        center.add(searchRow, BorderLayout.NORTH);
        center.add(UI.scroll(table), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ---- events
        cbCourse.addActionListener(e -> updateDeptLabel());
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedRow();
            }
        });
        debounce = new Timer(250, e -> loadStudents());
        debounce.setRepeats(false);
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { debounce.restart(); }
            public void removeUpdate(DocumentEvent e) { debounce.restart(); }
            public void changedUpdate(DocumentEvent e) { debounce.restart(); }
        });
        cbFilterDept.addActionListener(e -> {
            if (!suppressFilter) {
                fillFilterCourses();
                loadStudents();
            }
        });
        cbFilterCourse.addActionListener(e -> { if (!suppressFilter) { loadStudents(); } });
        cbSort.addActionListener(e -> loadStudents());
        btnAdd.addActionListener(e -> addStudent());
        btnUpdate.addActionListener(e -> updateStudent());
        btnDelete.addActionListener(e -> deleteStudent());
        btnClear.addActionListener(e -> clearForm());

        clearForm();
        loadStudents();
    }

    // ------------------------------------------------------------------ data

    private void fillFilterCourses() {
        suppressFilter = true;
        String dept = fixedDepartment != null ? fixedDepartment
                : (cbFilterDept.getSelectedIndex() > 0 ? (String) cbFilterDept.getSelectedItem() : null);
        cbFilterCourse.removeAllItems();
        cbFilterCourse.addItem("All Courses");
        for (String course : dept == null ? Department.getCourses() : Department.getCourses(dept)) {
            cbFilterCourse.addItem(course);
        }
        suppressFilter = false;
    }

    /** Re-reads the student list (also called when the panel is shown again). */
    public void reload() { loadStudents(); }

    private void loadStudents() {
        final String keyword = txtSearch.getText();
        final String dept = fixedDepartment != null ? fixedDepartment
                : (cbFilterDept.getSelectedIndex() > 0 ? (String) cbFilterDept.getSelectedItem() : null);
        final String course = cbFilterCourse.getSelectedIndex() > 0 ? (String) cbFilterCourse.getSelectedItem() : null;
        final int sort = cbSort.getSelectedIndex();
        new SwingWorker<List<Student>, Void>() {
            @Override protected List<Student> doInBackground() throws Exception {
                return StudentDAO.findAll(keyword, dept, course, sort);
            }

            @Override protected void done() {
                try {
                    students = get();
                    model.setRowCount(0);
                    for (Student s : students) {
                        model.addRow(new Object[] {s.getIdNumber(), s.getLastName(), s.getFirstName(),
                            s.getMiddleInitial() == null ? "" : s.getMiddleInitial(), s.getCourse(),
                            s.getDepartment() == null ? "" : s.getDepartment()});
                    }
                    lblCount.setText(students.size() + (students.size() == 1 ? " student" : " students"));
                } catch (Exception ex) {
                    UI.error(StudentManagementPanel.this, "Could not load students:\n"
                        + (ex.getCause() == null ? ex.getMessage() : ex.getCause().getMessage()));
                }
            }
        }.execute();
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= students.size()) {
            return;
        }
        selected = students.get(row);
        txtId.setText(selected.getIdNumber());
        txtLast.setText(selected.getLastName());
        txtFirst.setText(selected.getFirstName());
        txtMI.setText(selected.getMiddleInitial() == null ? "" : selected.getMiddleInitial());
        cbCourse.setSelectedItem(selected.getCourse());
        updateDeptLabel();
        refreshButtons();
    }

    private void updateDeptLabel() {
        String course = (String) cbCourse.getSelectedItem();
        String dept = cbCourse.getSelectedIndex() <= 0 ? "" : Department.getDepartment(course);
        lblDept.setText(dept.isEmpty() ? "\u2014" : dept);
    }

    private void refreshButtons() {
        btnAdd.setEnabled(selected == null);          // Add only for a NEW student (form cleared)
        btnUpdate.setEnabled(selected != null);
        btnDelete.setEnabled(selected != null);
    }

    private void clearForm() {
        selected = null;
        table.clearSelection();
        txtId.setText("");
        txtLast.setText("");
        txtFirst.setText("");
        txtMI.setText("");
        cbCourse.setSelectedIndex(0);
        updateDeptLabel();
        refreshButtons();
    }

    /** Validates the form; returns a Student or null (after showing the reason). */
    private Student readForm() {
        String id = txtId.getText().trim();
        String last = txtLast.getText().trim();
        String first = txtFirst.getText().trim();
        String mi = txtMI.getText().trim();

        if (id.isEmpty() || last.isEmpty() || first.isEmpty() || cbCourse.getSelectedIndex() <= 0) {
            UI.error(this, "Please fill in the Student ID Number, Last Name, First Name and Course.");
            return null;
        }
        boolean idUnchanged = selected != null && id.equals(selected.getIdNumber());
        if (!idUnchanged && !id.matches(ID_PATTERN)) {
            UI.error(this, "Invalid Student ID Number.\nUse the format 02-2324-04499.");
            txtId.requestFocus();
            return null;
        }
        if (!last.matches(NAME_PATTERN) || !first.matches(NAME_PATTERN)) {
            UI.error(this, "Names may only contain letters, spaces, periods, hyphens and apostrophes.");
            return null;
        }
        if (!mi.isEmpty() && !mi.matches("\\p{L}")) {
            UI.error(this, "Middle Initial must be a single letter.");
            return null;
        }
        Student s = new Student();
        s.setIdNumber(id);
        s.setLastName(last);
        s.setFirstName(first);
        s.setMiddleInitial(mi);
        s.setCourse((String) cbCourse.getSelectedItem());
        return s;
    }

    private void addStudent() {
        Student s = readForm();
        if (s == null) {
            return;
        }
        try {
            StudentDAO.insert(s);
            UI.info(this, "Student added.\nDepartment assigned: " + s.getDepartment());
            clearForm();
            loadStudents();
        } catch (StudentDAO.DuplicateStudentException ex) {
            UI.error(this, ex.getMessage());
        } catch (SQLException ex) {
            UI.error(this, "Database error: " + ex.getMessage());
        }
    }

    private void updateStudent() {
        if (selected == null) {
            UI.error(this, "Select a student from the table first.");
            return;
        }
        Student s = readForm();
        if (s == null) {
            return;
        }
        s.setId(selected.getId());
        if (!fullAccess) {
            s.setIdNumber(selected.getIdNumber());   // librarians cannot change the ID number
        }
        try {
            StudentDAO.update(s);
            UI.info(this, "Student record updated.\nDepartment: " + s.getDepartment());
            clearForm();
            loadStudents();
        } catch (StudentDAO.DuplicateStudentException ex) {
            UI.error(this, ex.getMessage());
        } catch (SQLException ex) {
            UI.error(this, "Database error: " + ex.getMessage());
        }
    }

    private void deleteStudent() {
        if (selected == null) {
            UI.error(this, "Select a student from the table first.");
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this,
            "Delete " + selected.getFullName() + " (" + selected.getIdNumber() + ")?\n"
          + "All of this student's attendance records will be deleted too.",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            StudentDAO.delete(selected.getId());
            UI.info(this, "Student deleted.");
            clearForm();
            loadStudents();
        } catch (SQLException ex) {
            UI.error(this, "Database error: " + ex.getMessage());
        }
    }
}
