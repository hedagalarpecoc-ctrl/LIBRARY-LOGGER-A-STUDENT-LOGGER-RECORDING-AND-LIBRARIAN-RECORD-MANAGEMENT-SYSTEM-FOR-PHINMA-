package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.admin;

public class AdminDAO {

    private AdminDAO() {}

    public static admin authenticate(String usernameOrEmail, char[] password) {
        String sql = "SELECT admin_id, admin_email, admin_lastname, admin_firstname, admin_username, admin_password "
                   + "FROM admin_tbl WHERE admin_username = ? OR admin_email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, usernameOrEmail.trim());
            pst.setString(2, usernameOrEmail.trim());

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String storedPassword = rs.getString("admin_password");
                    String inputPassword = new String(password);

                    if (storedPassword != null && storedPassword.equals(inputPassword)) {
                        return new admin(
                                rs.getInt("admin_id"),
                                rs.getString("admin_email"),
                                rs.getString("admin_lastname"),
                                rs.getString("admin_firstname"),
                                rs.getString("admin_username")
                        );
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // I-print sa console kung naay SQL error
        }
        return null;
    }
}