package model;

/**
 * One row of staff_tbl.
 * Represents a person who can log in to the Admin / Librarian dashboard.
 */
public class Staff {

    public static final String LIBRARIAN = "LIBRARIAN";

    private int id;
    private String email;
    private String lastname;
    private String firstname;
    private String username;
    private String password;

    public Staff() {
    }

    public Staff(int id, String lastname, String firstname, String username, String email) {
        this.id = id;
        this.lastname = lastname;
        this.firstname = firstname;
        this.username = username;
        this.email = email;
    }

    public Staff(int id, String email, String lastname, String firstname, String username, String password) {
        this.id = id;
        this.email = email;
        this.lastname = lastname;
        this.firstname = firstname;
        this.username = username;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getFullName() {
        return (firstname == null ? "" : firstname)
                + (lastname == null || lastname.isEmpty() ? "" : " " + lastname);
    }

}