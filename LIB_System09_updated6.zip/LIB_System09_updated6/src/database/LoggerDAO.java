//FOR TIME IN TIME OUT NI SYA
package database;

import department.Department;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import model.Student;

public class LoggerDAO {
    
    public static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("hh:mm:ss a");
    public static final DateTimeFormatter TABLE_TIME_FMT = DateTimeFormatter.ofPattern("hh:mm a");
    public static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("MMM dd, yyyy");

    // ------------------------------------------------------------------ logging

    public enum Status {
        SUCCESS,
        STUDENT_NOT_FOUND,
        ALREADY_TIMED_IN,     // tried Time In while still inside
        NO_TIME_IN,           // tried Time Out without a Time In today
        ALREADY_TIMED_OUT     // tried Time Out again after already timing out
    }

    public static class LogResult {
        public final Status status;
        public final Student student;     // null when the ID does not exist
        public final LocalTime time;      // time recorded (SUCCESS) or the relevant earlier time
        public final String message;

        LogResult(Status status, Student student, LocalTime time, String message) {
            this.status = status;
            this.student = student;
            this.time = time;
            this.message = message;
        }

        public boolean isSuccess() { return status == Status.SUCCESS; }
    }

    public static LogResult timeIn(String idNumber) throws SQLException {
        return log(idNumber, true);
    }

    public static LogResult timeOut(String idNumber) throws SQLException {
        return log(idNumber, false);
    }

    
    private static LogResult log(String idNumber, boolean isTimeIn) throws SQLException {
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now().withNano(0);

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                // lock the student's row so two quick clicks cannot create two open visits
                boolean exists;
                try (PreparedStatement pst = con.prepareStatement(
                        "SELECT student_id FROM student_tbl WHERE studentid_number = ? FOR UPDATE")) {
                    pst.setString(1, idNumber.trim());
                    try (ResultSet rs = pst.executeQuery()) {
                        exists = rs.next();
                    }
                }
                Student st = exists ? StudentDAO.findByIdNumber(con, idNumber) : null;
                if (st == null) {
                    con.rollback();
                    return new LogResult(Status.STUDENT_NOT_FOUND, null, null,
                        "Student ID Number not found. Please check your ID or see the librarian.");
                }

                // today's latest visit for this student
                int openId = -1;
                LocalTime openTimeIn = null;
                LocalTime lastTimeOut = null;
                try (PreparedStatement pst = con.prepareStatement(
                        "SELECT stud_logger_id, time_in, time_out FROM logger_tbl "
                      + "WHERE student_id = ? AND stud_date = ? ORDER BY time_in DESC, stud_logger_id DESC")) {
                    pst.setInt(1, st.getId());
                    pst.setDate(2, Date.valueOf(today));
                    try (ResultSet rs = pst.executeQuery()) {
                        while (rs.next()) {
                            Time out = rs.getTime("time_out");
                            if (out == null && openId < 0) {
                                openId = rs.getInt("stud_logger_id");
                                openTimeIn = rs.getTime("time_in").toLocalTime();
                            } else if (out != null && lastTimeOut == null) {
                                lastTimeOut = out.toLocalTime();
                            }
                        }
                    }
                }

                LogResult result;
                if (isTimeIn) {
                    if (openId >= 0) {
                        result = new LogResult(Status.ALREADY_TIMED_IN, st, openTimeIn,
                            "You already timed in today at " + openTimeIn.format(TIME_FMT) + ". Please Time Out first.");
                    } else {
                        try (PreparedStatement pst = con.prepareStatement(
                                "INSERT INTO logger_tbl (student_id, stud_date, time_in) VALUES (?,?,?)")) {
                            pst.setInt(1, st.getId());
                            pst.setDate(2, Date.valueOf(today));
                            pst.setTime(3, Time.valueOf(now));
                            pst.executeUpdate();
                        }
                        result = new LogResult(Status.SUCCESS, st, now, "Time In recorded.");
                    }
                } else {
                    if (openId >= 0) {
                        try (PreparedStatement pst = con.prepareStatement(
                                "UPDATE logger_tbl SET time_out = ? WHERE stud_logger_id = ? AND time_out IS NULL")) {
                            pst.setTime(1, Time.valueOf(now));
                            pst.setInt(2, openId);
                            pst.executeUpdate();
                        }
                        result = new LogResult(Status.SUCCESS, st, now, "Time Out recorded.");
                    } else if (lastTimeOut != null) {
                        result = new LogResult(Status.ALREADY_TIMED_OUT, st, lastTimeOut,
                            "You already timed out today at " + lastTimeOut.format(TIME_FMT)
                          + ". Time In first if you are coming back.");
                    } else {
                        result = new LogResult(Status.NO_TIME_IN, st, null,
                            "Invalid attendance: no Time In found for today. Please Time In first.");
                    }
                }
                con.commit();
                return result;
            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            }
        }
    }

    // ------------------------------------------------------------------ dashboard query

    public static final String[] SORT_OPTIONS = {
        "Date: Newest first", "Date: Oldest first", "Last name: A-Z", "Last name: Z-A", "Student ID Number"
    };

    /** Filters used by the Admin / Librarian / department tables. null or "" means "no filter". */
    public static class Filter {
        public String keyword;       // matches ID number, last name, first name or full name
        public LocalDate date;       // one specific date
        public String course;
        public String department;
        public int sortIndex;        // index into SORT_OPTIONS
    }

    /**
     * @return rows of: ID Number, Last Name, First Name, M.I., Course, Department, Date, Time In, Time Out
     */
    public static List<Object[]> search(Filter f) throws SQLException {
        StringBuilder sql = new StringBuilder(
            "SELECT s.studentid_number, s.lastname, s.firstname, s.middle_initial, "
          + "c." + Department.COURSE_COLUMN + " AS course, d.department_code AS department, "
          + "a.stud_date, a.time_in, a.time_out "
          + "FROM logger_tbl a JOIN student_tbl s ON s.student_id = a.student_id "
          + "LEFT JOIN course_tbl c ON c.course_id = s.course_id "
          + "LEFT JOIN dept_tbl d ON d.department_id = c.department_id WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (f.keyword != null && !f.keyword.trim().isEmpty()) {
            sql.append(" AND (s.studentid_number LIKE ? OR s.lastname LIKE ? OR s.firstname LIKE ?"
                     + " OR CONCAT(s.firstname,' ',s.lastname) LIKE ? OR CONCAT(s.lastname,', ',s.firstname) LIKE ?)");
            String like = "%" + f.keyword.trim() + "%";
            for (int i = 0; i < 5; i++) {
                params.add(like);
            }
        }
        if (f.date != null) {
            sql.append(" AND a.stud_date = ?");
            params.add(Date.valueOf(f.date));
        }
        if (f.course != null && !f.course.isEmpty()) {
            sql.append(" AND c." + Department.COURSE_COLUMN + " = ?");
            params.add(f.course);
        }
        if (f.department != null && !f.department.isEmpty()) {
            sql.append(" AND d.department_code = ?");
            params.add(f.department);
        }

        switch (f.sortIndex) {
            case 1:  sql.append(" ORDER BY a.stud_date ASC, a.time_in ASC"); break;
            case 2:  sql.append(" ORDER BY s.lastname ASC, s.firstname ASC, a.stud_date DESC, a.time_in DESC"); break;
            case 3:  sql.append(" ORDER BY s.lastname DESC, s.firstname DESC, a.stud_date DESC, a.time_in DESC"); break;
            case 4:  sql.append(" ORDER BY s.studentid_number ASC, a.stud_date DESC, a.time_in DESC"); break;
            default: sql.append(" ORDER BY a.stud_date DESC, a.time_in DESC"); break;
        }

        List<Object[]> rows = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Time in = rs.getTime("time_in");
                    Time out = rs.getTime("time_out");
                    rows.add(new Object[] {
                        rs.getString("studentid_number"),
                        rs.getString("lastname"),
                        rs.getString("firstname"),
                        nz(rs.getString("middle_initial")),
                        nz(rs.getString("course")),
                        nz(rs.getString("department")),
                        rs.getDate("stud_date").toLocalDate().format(DATE_FMT),
                        in == null ? "" : in.toLocalTime().format(TABLE_TIME_FMT),
                        out == null ? "\u2014" : out.toLocalTime().format(TABLE_TIME_FMT)
                    });
                }
            }
        }
        return rows;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
    
}
