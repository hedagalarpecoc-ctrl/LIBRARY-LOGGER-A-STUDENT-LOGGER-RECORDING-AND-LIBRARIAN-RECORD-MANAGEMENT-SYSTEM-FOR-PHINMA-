-- =====================================================================
--  Library Attendance Logger  -  database setup / migration script
--  Run ONCE in phpMyAdmin:  library_attendance_system  ->  SQL tab
--  (Safe to run again: every step checks before it changes anything.)
-- =====================================================================
USE library_attendance_system;

-- 1) Remove duplicate student rows (your table has 02-2324-04499 three times).
--    The row with the lowest student_id is kept.
DELETE s1 FROM student s1
JOIN student s2
  ON s1.studentid_number = s2.studentid_number
 AND s1.student_id > s2.student_id;

-- 2) Make sure a Student ID Number can never be registered twice.
SET @has_idx := (SELECT COUNT(*) FROM information_schema.statistics
                 WHERE table_schema = DATABASE()
                   AND table_name = 'student'
                   AND index_name = 'uq_student_idnumber');
SET @sql := IF(@has_idx = 0,
    'ALTER TABLE student ADD UNIQUE KEY uq_student_idnumber (studentid_number)',
    'SELECT ''unique key already exists''');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 3) Attendance table.  student_id is the FOREIGN KEY to student.student_id.
--    One row = one visit (date + Time In + Time Out).  time_out stays NULL
--    until the student times out.  Deleting a student deletes their attendance.
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id   INT          NOT NULL AUTO_INCREMENT,
    student_id      INT          NOT NULL,
    attendance_date DATE         NOT NULL,
    time_in         TIME         NOT NULL,
    time_out        TIME         NULL,
    PRIMARY KEY (attendance_id),
    KEY idx_att_student_date (student_id, attendance_date),
    KEY idx_att_date (attendance_date),
    CONSTRAINT fk_attendance_student
        FOREIGN KEY (student_id) REFERENCES student (student_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4) Fill the department column from the course (same mapping as department.Department).
--    The Java program also does this automatically on start-up and whenever a student is saved.
UPDATE student SET department = CASE course
    WHEN 'BS Nursing' THEN 'CAHS'
    WHEN 'BS Medical Technology' THEN 'CAHS'
    WHEN 'BS Pharmacy' THEN 'CAHS'
    WHEN 'BS Psychology' THEN 'CAHS'
    WHEN 'BS Information Technology' THEN 'CITE'
    WHEN 'BS Computer Science' THEN 'CITE'
    WHEN 'BS Accountancy' THEN 'CMA'
    WHEN 'BS Business Administration' THEN 'CMA'
    WHEN 'BS Management Accounting' THEN 'CMA'
    WHEN 'BS Hospitality Management' THEN 'CMA'
    WHEN 'BS Tourism Management' THEN 'CMA'
    WHEN 'Bachelor of Elementary Education' THEN 'CEA'
    WHEN 'Bachelor of Early Childhood Education' THEN 'CEA'
    WHEN 'Bachelor of Secondary Education' THEN 'CEA'
    WHEN 'BA Communication' THEN 'CEA'
    WHEN 'BS Architecture' THEN 'COE'
    WHEN 'BS Civil Engineering' THEN 'COE'
    WHEN 'BS Computer Engineering' THEN 'COE'
    WHEN 'BS Electrical Engineering' THEN 'COE'
    WHEN 'BS Mechanical Engineering' THEN 'COE'
    WHEN 'BS Criminology' THEN 'SCCJ'
    ELSE department END;
