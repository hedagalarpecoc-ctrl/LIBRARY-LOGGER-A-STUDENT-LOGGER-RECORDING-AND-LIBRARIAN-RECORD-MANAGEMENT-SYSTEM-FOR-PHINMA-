package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import model.Staff;

public class StaffDAO {

    // Gi-remove na ang role column sa SELECT
    private static final String SELECT_COLS =
            "staff_id, staff_email, staff_lastname, staff_firstname, staff_username";

    private StaffDAO() {
    }

    // LOGIN (Plain text password check)
    public static Staff authenticate(String usernameOrEmail, char[] password) throws SQLException {
        String sql = "SELECT " + SELECT_COLS + ", staff_password FROM staff_tbl "
                + "WHERE staff_username = ? OR staff_email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, usernameOrEmail.trim());
            pst.setString(2, usernameOrEmail.trim());

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String storedPassword = rs.getString("staff_password");
                    String inputPassword = new String(password);

                    // Direct comparison ra sa plain text password
                    if (storedPassword != null && storedPassword.equals(inputPassword)) {
                        return map(rs);
                    }
                }
            }
        }

        return null;
    }

    // FIND ACCOUNT
    public static Staff findByUsernameOrEmail(String usernameOrEmail) throws SQLException {
        String sql = "SELECT " + SELECT_COLS + " FROM staff_tbl WHERE staff_username = ? OR staff_email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, usernameOrEmail.trim());
            pst.setString(2, usernameOrEmail.trim());

            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    // CHECK USERNAME
    public static boolean usernameExists(String username) throws SQLException {
        return exists("staff_username", username);
    }

    // CHECK EMAIL
    public static boolean emailExists(String email) throws SQLException {
        return exists("staff_email", email);
    }

    private static boolean exists(String column, String value) throws SQLException {
        if (!column.equals("staff_username") && !column.equals("staff_email")) {
            throw new IllegalArgumentException("Invalid column: " + column);
        }

        String sql = "SELECT 1 FROM staff_tbl WHERE " + column + " = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, value.trim());

            try (ResultSet rs = pst.executeQuery()) {
                return rs.next();
            }
        }
    }

    // SIGN UP - LIBRARIAN (Plain text password)
    public static Staff register(
            String email,
            String lastname,
            String firstname,
            String username,
            char[] password)
            throws SQLException, DuplicateStaffException {

        if (usernameExists(username)) {
            throw new DuplicateStaffException("Username");
        }

        if (emailExists(email)) {
            throw new DuplicateStaffException("Email");
        }

        // 5 columns lang ang gi-insert
        String sql = "INSERT INTO staff_tbl "
                + "(staff_email, staff_lastname, staff_firstname, staff_username, staff_password) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pst.setString(1, email.trim());
            pst.setString(2, lastname.trim());
            pst.setString(3, firstname.trim());
            pst.setString(4, username.trim());
            pst.setString(5, new String(password)); // Plain text password
            pst.executeUpdate();

            try (ResultSet keys = pst.getGeneratedKeys()) {
                if (keys.next()) {
                    return new Staff(
                            keys.getInt(1),
                            email.trim(),
                            lastname.trim(),
                            firstname.trim(),
                            username.trim(),
                            Staff.LIBRARIAN
                    );
                }
            }

        } catch (SQLIntegrityConstraintViolationException ex) {
            throw new DuplicateStaffException("Username or Email");
        }

        throw new SQLException("Unable to register staff account.");
    }

    // FORGOT PASSWORD (Plain text password update)
    public static boolean resetPassword(String usernameOrEmail, char[] newPassword) throws SQLException {
        String sql = "UPDATE staff_tbl SET staff_password = ? WHERE staff_username = ? OR staff_email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, new String(newPassword)); // Plain text
            pst.setString(2, usernameOrEmail.trim());
            pst.setString(3, usernameOrEmail.trim());

            return pst.executeUpdate() > 0;
        }
    }

    // READ STAFF DATA
    private static Staff map(ResultSet rs) throws SQLException {
        return new Staff(
                rs.getInt("staff_id"),
                rs.getString("staff_email"),
                rs.getString("staff_lastname"),
                rs.getString("staff_firstname"),
                rs.getString("staff_username"),
                Staff.LIBRARIAN // Default role gamit ang Constant
        );
    }

    public static class DuplicateStaffException extends Exception {
        public DuplicateStaffException(String what) {
            super(what + " is already registered.");
        }
    }
}