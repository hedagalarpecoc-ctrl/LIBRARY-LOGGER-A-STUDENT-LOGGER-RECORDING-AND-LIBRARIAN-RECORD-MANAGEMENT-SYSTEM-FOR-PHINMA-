-- =====================================================================
--  Senior High School (SHS) department + strands
--  Database: library_logger  ->  phpMyAdmin > library_logger > SQL tab > paste > Go
--  Safe to run more than once. Existing students keep their records; if a
--  strand code (e.g. TVL) already exists, it is moved under SHS instead of duplicated.
-- =====================================================================
USE library_logger;

-- 1) The SHS department
INSERT INTO dept_tbl (department_code, department_name)
SELECT 'SHS', 'Senior High School'
WHERE NOT EXISTS (SELECT 1 FROM dept_tbl WHERE department_code = 'SHS');

SET @shs := (SELECT department_id FROM dept_tbl WHERE department_code = 'SHS' LIMIT 1);

-- 2) Strands that already exist in course_tbl -> move under SHS
UPDATE course_tbl SET department_id = @shs
WHERE course_code IN ('ABM','TVL','HUMSS','GAS','STEM');

-- 3) Strands that do not exist yet -> insert
INSERT INTO course_tbl (course_code, course_name, department_id)
SELECT v.code, v.name, @shs FROM (
    SELECT 'ABM'   AS code, 'Accountancy, Business, and Management'            AS name UNION ALL
    SELECT 'TVL',          'Technical-Vocational-Livelihood'                         UNION ALL
    SELECT 'HUMSS',        'Humanities and Social Sciences'                          UNION ALL
    SELECT 'GAS',          'General Academic Strand'                                 UNION ALL
    SELECT 'STEM',         'Science, Technology, Engineering, and Mathematics'
) v
WHERE NOT EXISTS (SELECT 1 FROM course_tbl c WHERE c.course_code = v.code);
