package department;

/** Kept only so older code still compiles - it simply delegates to {@link Department}. */
public class DepartmentMapper {
    public static String getDepartment(String course) {
        return Department.getDepartment(course);
    }
}
