package GUI;

/** COE Department panel - shows only the attendance of students whose department is COE. */
public class COEPanel extends AttendanceTablePanel {
    public COEPanel() {
        super("COE", "COE DEPARTMENT", "Attendance records of COE students");
    }
}
