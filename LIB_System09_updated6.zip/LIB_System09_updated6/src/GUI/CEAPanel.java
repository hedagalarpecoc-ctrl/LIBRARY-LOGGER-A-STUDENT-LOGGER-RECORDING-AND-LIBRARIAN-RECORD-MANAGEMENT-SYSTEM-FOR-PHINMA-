package GUI;

/** CEA Department panel - shows only the attendance of students whose department is CEA. */
public class CEAPanel extends AttendanceTablePanel {
    public CEAPanel() {
        super("CEA", "CEA DEPARTMENT", "Attendance records of CEA students");
    }
}
