package model;

public class admin {
    private final int id;
    private final String email;
    private final String lastname;
    private final String firstname;
    private final String username;

    public admin(int id, String email, String lastname, String firstname, String username) {
        this.id = id;
        this.email = email;
        this.lastname = lastname;
        this.firstname = firstname;
        this.username = username;
    }

    public int getId() { return id; }
    public String getEmail() { return email; }
    public String getLastname() { return lastname; }
    public String getFirstname() { return firstname; }
    public String getUsername() { return username; }
}