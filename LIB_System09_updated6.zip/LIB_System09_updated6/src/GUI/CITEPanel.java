package GUI;

/** CITE Department panel - shows only the attendance of students whose department is CITE. */
public class CITEPanel extends AttendanceTablePanel {
    public CITEPanel() {
        super("CITE", "CITE DEPARTMENT", "Attendance records of CITE students");
    }
}
