package model;

/** One row of the student table. */
public class Student {
    private int id;                 // student.student_id (primary key)
    private String idNumber;        // student.studentid_number (e.g. 02-2324-04499)
    private String lastName;
    private String firstName;
    private String middleInitial;
    private String course;
    private String department;

    public Student() { }

    public Student(int id, String idNumber, String lastName, String firstName,
                   String middleInitial, String course, String department) {
        this.id = id;
        this.idNumber = idNumber;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.course = course;
        this.department = department;
    }
    

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getIdNumber() { return idNumber; }
    public void setIdNumber(String idNumber) { this.idNumber = idNumber; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getMiddleInitial() { return middleInitial; }
    public void setMiddleInitial(String middleInitial) { this.middleInitial = middleInitial; }
    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getFullName() {
        String mi = (middleInitial == null || middleInitial.isBlank()) ? "" : " " + middleInitial + ".";
        return firstName + mi + " " + lastName;
    }
    
}
