package GUI;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.net.URL;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;

public final class UI {

    public static final Color GREEN      = new Color(0, 102, 0);
    public static final Color DARK_GREEN = new Color(0, 51, 0);
    public static final Color LIGHT_GREEN = new Color(0, 153, 51);
    public static final Color GOLD       = new Color(201, 162, 39);     // muted academic gold (was bright lemon yellow)
    public static final Color GOLD_SOFT  = new Color(250, 241, 205);
    public static final Color PAGE_BG    = new Color(246, 248, 246);
    public static final Color ROW_ALT    = new Color(235, 245, 235);
    public static final Color BORDER     = new Color(200, 210, 200);
    public static final Color ERROR_RED  = new Color(176, 0, 32);
    public static final Color GRAY       = new Color(110, 110, 110);

    public static final Font TITLE   = new Font("Serif", Font.BOLD, 30);
    public static final Font HEADING = new Font("Serif", Font.BOLD, 18);
    public static final Font LABEL   = new Font("Serif", Font.BOLD, 14);
    public static final Font BODY    = new Font("SansSerif", Font.PLAIN, 14);
    public static final Font BUTTON  = new Font("SansSerif", Font.BOLD, 13);

    /** One corner radius for small controls (buttons, text fields) and one for panels/cards, used everywhere. */
    public static final int RADIUS = 10;
    public static final int CARD_RADIUS = 16;

    private UI() { }

    public static void installLookAndFeel() {
        UIManager.put("nimbusFocus", GOLD);          // gold focus ring instead of Nimbus blue
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) { }
    }

    public static ImageIcon icon(String resource) {
        URL url = UI.class.getResource(resource);
        return url == null ? null : new ImageIcon(url);
    }

    public static Image image(String resource) {
        ImageIcon i = icon(resource);
        return i == null ? null : i.getImage();
    }


    /** Logo/image scaled to a fixed height (keeps aspect ratio). */
    public static ImageIcon scaledIcon(String resource, int height) {
        Image img = image(resource);
        if (img == null) {
            return null;
        }
        int w = img.getWidth(null), h = img.getHeight(null);
        return new ImageIcon(img.getScaledInstance(Math.max(1, w * height / h), height, Image.SCALE_SMOOTH));
    }

    public enum Glyph { CLOCK, PEOPLE, LOGOUT }

    /** Simple line icons drawn with Java2D, so they stay sharp and need no image files. */
    public static class NavIcon implements Icon {
        private final Glyph glyph;

        public NavIcon(Glyph glyph) { this.glyph = glyph; }

        @Override public int getIconWidth() { return 20; }
        @Override public int getIconHeight() { return 20; }

        @Override public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            boolean on = c instanceof FlatButton && ((FlatButton) c).isActive() && c.isEnabled();
            g2.setColor(on ? DARK_GREEN : Color.WHITE);
            g2.translate(x + 1, y + 1);
            switch (glyph) {
                case CLOCK:
                    g2.drawOval(0, 0, 17, 17);
                    g2.drawLine(8, 8, 8, 3);
                    g2.drawLine(8, 8, 12, 10);
                    break;
                case PEOPLE:
                    g2.drawOval(5, 0, 7, 7);
                    g2.drawArc(1, 10, 15, 14, 0, 180);
                    break;
                default:   // LOGOUT
                    g2.drawLine(7, 1, 1, 1);
                    g2.drawLine(1, 1, 1, 16);
                    g2.drawLine(1, 16, 7, 16);
                    g2.drawLine(6, 8, 16, 8);
                    g2.drawLine(12, 4, 16, 8);
                    g2.drawLine(12, 12, 16, 8);
                    break;
            }
            g2.dispose();
        }
    }

    // ---------------------------------------------------------------- buttons

    /** Flat rounded button that looks identical under any look-and-feel. */
    public static class FlatButton extends JButton {
        private Color base;
        private boolean active;

        public FlatButton(String text, Color base) {
            super(text);
            this.base = base;
            setFont(BUTTON);
            setForeground(Color.WHITE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        }

        @Override public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            return new Dimension(d.width, Math.max(d.height, 34));    // every button is at least 34 px tall
        }

        @Override public void updateUI() { setUI(new BasicButtonUI()); }

        public void setActive(boolean active) { this.active = active; repaint(); }

        public boolean isActive() { return active; }

        public void setBase(Color c) { this.base = c; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            Color c = base;
            if (!isEnabled()) {
                c = new Color(160, 170, 160);
            } else if (getModel().isPressed()) {
                c = base.darker();
            } else if (active) {
                c = GOLD;
            } else if (getModel().isRollover()) {
                c = base.brighter();
            }
            g2.setColor(c);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), RADIUS * 2, RADIUS * 2));
            g2.dispose();
            setForeground(active && isEnabled() ? DARK_GREEN : Color.WHITE);
            super.paintComponent(g);
        }
    }

    public static FlatButton button(String text, Color color) {
        return new FlatButton(text, color);
    }

    // ---------------------------------------------------------------- inputs

    /** Plain (square) field border - kept for any component that is not one of the rounded fields. */
    public static Border fieldBorder() {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(4, 8, 4, 8));
    }

    /** Draws the rounded white box, hint text and outline shared by RoundedTextField / RoundedPasswordField. */
    private static void paintField(JTextComponent f, Graphics g, String hint, Runnable paintText) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        int w = f.getWidth(), h = f.getHeight();
        g2.setColor(f.isEnabled() && f.isEditable() ? Color.WHITE : new Color(243, 245, 243));
        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, RADIUS * 2, RADIUS * 2));
        g2.dispose();

        paintText.run();                                       // text + caret + selection

        g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        if (hint != null && f.getDocument().getLength() == 0 && !f.isFocusOwner()) {
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(new Color(150, 150, 150));
            g2.setFont(f.getFont().deriveFont(Font.ITALIC));
            Insets in = f.getInsets();
            g2.drawString(hint, in.left, (h + g2.getFontMetrics().getAscent() - g2.getFontMetrics().getDescent()) / 2);
        }
        boolean focus = f.isFocusOwner();
        g2.setColor(focus ? LIGHT_GREEN : BORDER);
        g2.setStroke(new BasicStroke(focus ? 2f : 1f));
        float o = focus ? 1f : 0.5f;
        g2.draw(new RoundRectangle2D.Float(o, o, w - 2 * o, h - 2 * o, RADIUS * 2, RADIUS * 2));
        g2.dispose();
    }

    /** Text field with rounded corners (and an optional grey hint shown while empty). */
    public static class RoundedTextField extends JTextField {
        private final String hint;

        public RoundedTextField(String hint, int columns) {
            super(columns);
            this.hint = hint;
            setOpaque(false);
            setFont(BODY);
            setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            paintField(this, g, hint, () -> super.paintComponent(g));
        }
    }

    /** Password field with rounded corners (and an optional hint). */
    public static class RoundedPasswordField extends JPasswordField {
        private final String hint;

        public RoundedPasswordField(String hint) {
            this.hint = hint;
            setOpaque(false);
            setFont(BODY);
            setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            paintField(this, g, hint, () -> super.paintComponent(g));
        }
    }

    public static JTextField textField(int columns) {
        JTextField f = new RoundedTextField(null, columns);
        f.setPreferredSize(new Dimension(f.getPreferredSize().width, 34));
        return f;
    }

    public static <T> JComboBox<T> combo(T[] items) {
        JComboBox<T> c = new JComboBox<>(items);
        c.setFont(BODY);
        c.setPreferredSize(new Dimension(c.getPreferredSize().width, 34));
        return c;
    }

    public static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(LABEL);
        l.setForeground(GREEN);
        return l;
    }

    /** Same name as before, now rounded: a text field that shows a hint while it is empty. */
    public static class HintTextField extends RoundedTextField {
        public HintTextField(String hint) {
            super(hint, 0);
        }
    }

    /** Clickable text ("Forgot Password?", "Sign Up", "Back to Login") - hand cursor, underline on hover. */
    public static class LinkLabel extends JLabel {
        public LinkLabel(String text, Runnable onClick) {
            super(text);
            setFont(new Font("SansSerif", Font.BOLD, 13));
            setForeground(GREEN);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { onClick.run(); }

                @Override public void mouseEntered(MouseEvent e) {
                    setForeground(LIGHT_GREEN);
                    setText("<html><u>" + text + "</u></html>");
                }

                @Override public void mouseExited(MouseEvent e) {
                    setForeground(GREEN);
                    setText(text);
                }
            });
        }
    }

    // ---------------------------------------------------------------- panels

    /**
     * Panel with rounded corners. Its children are clipped to the rounded shape, so a square header or table
     * inside it gets rounded corners too. Works at any size - the shape is recalculated on every paint.
     */
    public static class RoundedPanel extends JPanel {
        private final int radius;
        private Color fill;
        private Color outline;

        public RoundedPanel(LayoutManager layout, int radius, Color fill, Color outline) {
            super(layout);
            this.radius = radius;
            this.fill = fill;
            this.outline = outline;
            setOpaque(false);
        }

        public RoundedPanel(int radius, Color fill, Color outline) {
            this(new BorderLayout(), radius, fill, outline);
        }

        public void setFill(Color c) { this.fill = c; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            if (fill == null) {
                return;
            }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fill);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius * 2, radius * 2));
            g2.dispose();
        }

        @Override protected void paintChildren(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.clip(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius * 2, radius * 2));
            super.paintChildren(g2);
            g2.dispose();
            if (outline != null) {
                g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
                g2.setColor(outline);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, radius * 2, radius * 2));
                g2.dispose();
            }
        }
    }

    /** Panel that paints the campus picture (panel_bg.png) scaled to fill, with an optional white wash on top. */
    public static class BackgroundPanel extends JPanel {
        private final Image img = image("/GUI/panel_bg.png");
        private final float wash;
        private final int radius;      // 0 = square corners

        public BackgroundPanel(float wash) {
            this(wash, 0);
        }

        public BackgroundPanel(float wash, int radius) {
            this.wash = wash;
            this.radius = radius;
            setOpaque(radius == 0);
            setBackground(Color.WHITE);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            if (radius > 0) {
                g2.clip(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius * 2, radius * 2));
            }
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, getWidth(), getHeight());
            if (img != null) {
                double s = Math.max(getWidth() / (double) img.getWidth(null), getHeight() / (double) img.getHeight(null));
                int w = (int) Math.ceil(img.getWidth(null) * s), h = (int) Math.ceil(img.getHeight(null) * s);
                g2.drawImage(img, (getWidth() - w) / 2, (getHeight() - h) / 2, w, h, null);
            }
            if (wash > 0) {
                g2.setColor(new Color(1f, 1f, 1f, wash));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
            g2.dispose();
            if (radius > 0) {
                g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, radius * 2, radius * 2));
                g2.dispose();
            }
        }
    }

    /** White rounded card with a green title bar. The title can be changed with setTitle(). */
    public static class Card extends RoundedPanel {
        private final JLabel head;

        public Card(String title) {
            super(CARD_RADIUS, Color.WHITE, BORDER);
            head = new JLabel(title, SwingConstants.CENTER);
            head.setOpaque(true);
            head.setBackground(GREEN);
            head.setForeground(Color.WHITE);
            head.setFont(HEADING);
            head.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
            add(head, BorderLayout.NORTH);
        }

        public void setTitle(String title) { head.setText(title); }
    }

    public static JPanel card(String title) {
        return new Card(title);
    }

    public static void styleTable(JTable table) {
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(225, 232, 225));
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(GOLD_SOFT);
        table.setSelectionForeground(Color.BLACK);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        DefaultTableCellRenderer cell = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                    boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, false, row, col);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                if (!sel) {
                    setBackground(row % 2 == 0 ? Color.WHITE : ROW_ALT);
                    setForeground(Color.DARK_GRAY);
                }
                return this;
            }
        };
        table.setDefaultRenderer(Object.class, cell);

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                    boolean foc, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, false, false, row, col);
                l.setOpaque(true);
                l.setBackground(GREEN);
                l.setForeground(Color.WHITE);
                l.setFont(new Font("SansSerif", Font.BOLD, 13));
                l.setHorizontalAlignment(SwingConstants.LEFT);
                l.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return l;
            }
        });
    }

    /** The table inside a rounded white box (the green header row is clipped to the rounded corners). */
    public static JComponent scroll(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setOpaque(false);
        sp.getViewport().setBackground(Color.WHITE);
        RoundedPanel box = new RoundedPanel(CARD_RADIUS - 4, Color.WHITE, BORDER);
        box.add(sp, BorderLayout.CENTER);
        return box;
    }

    public static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void warn(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }

    public static void info(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
}
