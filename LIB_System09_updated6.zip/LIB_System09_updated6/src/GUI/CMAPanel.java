package GUI;

/** CMA Department panel - shows only the attendance of students whose department is CMA. */
public class CMAPanel extends AttendanceTablePanel {
    public CMAPanel() {
        super("CMA", "CMA DEPARTMENT", "Attendance records of CMA students");
    }
}
