package librarian_gui;

import GUI.DashboardFrame;
import GUI.UI;
import model.Staff;

/** Librarian: same layout as the Admin, but students can only be viewed and updated. */
public class Librarian extends DashboardFrame {

    public Librarian() {
        this(null);
    }

    /** @param staff the account that logged in (shown in the header); may be null. */
    public Librarian(Staff staff) {
        super("LIBRARIAN", false, staff);
    }

    public static void main(String[] args) {
        UI.installLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Librarian().setVisible(true));
    }
}
